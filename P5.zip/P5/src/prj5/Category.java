package prj5;

public enum Category {
    hobby, major, region;
}
