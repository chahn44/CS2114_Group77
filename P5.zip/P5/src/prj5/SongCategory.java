package prj5;

public enum SongCategory {
    Artist, Year, Genre, Other;
}
