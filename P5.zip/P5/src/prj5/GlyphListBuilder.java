package prj5;

import java.util.ArrayList;
import music.DoublyLinkedList;
import music.Glyph;
import music.Song;

public class GlyphListBuilder {

    private DoublyLinkedList<Song> songs;
    private ArrayList<Glyph> glyphsByMajor;
    private ArrayList<Glyph> glyphsByHobby;
    private ArrayList<Glyph> glyphsByRegion;


    /**
     * Initializes the DoublyLinkedList, and 3 Array Lists
     * that will store the Glyphs generated based on Major,
     * Hobby and Region
     * 
     * @param songList
     *            the DoublyLinkedList passed in
     */
    public GlyphListBuilder(DoublyLinkedList<Song> songList) {
        songs = songList;
        glyphsByMajor = new ArrayList<Glyph>();
        glyphsByHobby = new ArrayList<Glyph>();
        glyphsByRegion = new ArrayList<Glyph>();
    }


    /**
     * Returns the song list
     * 
     * @return songs
     *         the list of songs
     */
    public DoublyLinkedList<Song> getSongs() {
        return songs;
    }


    /**
     * Gets the List of Glyphs by major
     * 
     * @return glyphsByMajor
     *         the ArrayList storing the glyphs
     */
    public ArrayList<Glyph> getGlyphsByMajor() {
        return glyphsByMajor;
    }


    /**
     * Gets the List of Glyphs by hobby
     * 
     * @return glyphsByHobby
     *         the ArrayList storing the glyphs
     */
    public ArrayList<Glyph> getGlyphsByHobby() {
        return glyphsByHobby;
    }


    /**
     * Gets the List of Glyphs by region
     * 
     * @return glyphsByRegion
     *         the ArrayList storing the glyphs
     */
    public ArrayList<Glyph> getGlyphsByRegion() {
        return glyphsByRegion;
    }


    /**
     * Generates Glyphs based on the percentages 
     * calculated for the majors and stores them 
     * in an ArrayList
     * 
     * @return glyphsByMajor
     *         the ArrayList storing the glyphs
     */
    public ArrayList<Glyph> createGlyphsByMajor() {
        for (int i = 0; i < songs.size(); i++) {
            Song current = songs.get(i);
            int likePercent = current.majorPercent[1]; // need percentages
            int heardPercent = current.majorPercent[0]; // need percentages
            Glyph currentGlyph = new Glyph();
            currentGlyph.createLikeBar(1, likePercent);
            currentGlyph.createHeardBar(5, heardPercent);
            int likePercentTwo = current.majorPercent[3]; // need percentages
            int heardPercentTwo = current.majorPercent[2]; // need percentages
            currentGlyph.createLikeBar(2, likePercentTwo);
            currentGlyph.createHeardBar(6, heardPercentTwo);
            int likePercentThree = current.majorPercent[5]; // need percentages
            int heardPercentThree = current.majorPercent[4]; // need percentages
            currentGlyph.createLikeBar(3, likePercentThree);
            currentGlyph.createHeardBar(7, heardPercentThree);
            int likePercentFour = current.majorPercent[7]; // need percentages
            int heardPercentFour = current.majorPercent[6]; // need percentages
            currentGlyph.createLikeBar(4, likePercentFour);
            currentGlyph.createHeardBar(8, heardPercentFour);
            glyphsByMajor.add(currentGlyph);
        }
        return glyphsByMajor;
    }


    /**
     * Generates Glyphs based on the percentages 
     * calculated for the hobbies and stores them 
     * in an ArrayList
     * 
     * @return glyphsByHobby
     *         the ArrayList storing the glyphs
     */
    public ArrayList<Glyph> createGlyphsByHobby() {
        for (int i = 0; i < songs.size(); i++) {
            Song current = songs.get(i);

            int likePercent = current.hobbyPercent[1]; // need percentages
            int heardPercent = current.hobbyPercent[0]; // need percentages

            Glyph currentGlyph = new Glyph();
            currentGlyph.createLikeBar(1, likePercent);
            currentGlyph.createHeardBar(5, heardPercent);

            int likePercent2 = current.hobbyPercent[3]; // need percentages
            int heardPercent2 = current.hobbyPercent[2]; // need percentages

            currentGlyph.createLikeBar(2, likePercent2);
            currentGlyph.createHeardBar(6, heardPercent2);

            int likePercent3 = current.hobbyPercent[5]; // need percentages
            int heardPercent3 = current.hobbyPercent[4]; // need percentages

            currentGlyph.createLikeBar(3, likePercent3);
            currentGlyph.createHeardBar(7, heardPercent3);

            int likePercent4 = current.hobbyPercent[7]; // need percentages
            int heardPercent4 = current.hobbyPercent[6]; // need percentages

            currentGlyph.createLikeBar(4, likePercent4);
            currentGlyph.createHeardBar(8, heardPercent4);

            glyphsByHobby.add(currentGlyph);
        }
        return glyphsByHobby;
    }


    /**
     * Generates Glyphs based on the percentages 
     * calculated for the states and stores them 
     * in an ArrayList
     * 
     * @return glyphsByREgion
     *         the ArrayList storing the glyphs
     */
    public ArrayList<Glyph> createGlyphsByRegion() {
        for (int i = 0; i < songs.size(); i++) {
            Song current = songs.get(i);

            int likePercent = current.regionPercent[1]; // need percentages
            int heardPercent = current.regionPercent[0]; // need percentages

            Glyph currentGlyph = new Glyph();
            currentGlyph.createLikeBar(1, likePercent);
            currentGlyph.createHeardBar(5, heardPercent);

            int likePercent2 = current.regionPercent[3]; // need percentages
            int heardPercent2 = current.regionPercent[2]; // need percentages

            currentGlyph.createLikeBar(2, likePercent2);
            currentGlyph.createHeardBar(6, heardPercent2);

            int likePercent3 = current.regionPercent[5]; // need percentages
            int heardPercent3 = current.regionPercent[4]; // need percentages

            currentGlyph.createLikeBar(3, likePercent3);
            currentGlyph.createHeardBar(7, heardPercent3);

            int likePercent4 = current.regionPercent[7]; // need percentages
            int heardPercent4 = current.regionPercent[6]; // need percentages

            currentGlyph.createLikeBar(4, likePercent4);
            currentGlyph.createHeardBar(8, heardPercent4);

            glyphsByRegion.add(currentGlyph);
        }
        return glyphsByRegion;
    }
}
