package prj5;

/**
 * @author Johnny
 *
 */
public class Song {
    //Fields
    private String songTitle;
    private String songGenre;
    private int songYear;
    private String songArtist;
    private int songNumber;
    private int[][] hobbyInfo;
    private int[][] majorInfo;
    private int[][] regionInfo;
 
    
    /**
     * constructor, sets all fields for a given song
     * @param title = title of the song as String
     * @param genre = song genre
     * @param year = song year
     * @param artist = song artist
     */
    public Song(String title, String genre, int year, String artist, int songNum)
    {
        songTitle = title;
        songGenre = genre;
        songYear = year;
        songArtist = artist;
        songNumber = songNum;
        hobbyInfo = new int[2][4];
        majorInfo = new int[2][4];
        regionInfo = new int[2][4];
       
    }
    
    /**
     * returns the title of a song
     * @return = song title
     */
    public String getTitle()
    {
        return songTitle;
    }
    
    /**
     * returns song genre
     * @return = song genre
     */
    public String getGenre()
    {
        return songGenre;
    }
    
    /**
     * retruns song year
     * @return = song year
     */
    public int getYear()
    {
        return songYear;
    }
    
    /**
     * returns the song artist
     * @return = song artist
     */
    public String getArtist()
    {
        return songArtist;
    }
    
    
    /**
     * Returns a string representation of all data about song
     * in order [title, artist, genre, year]
     * 
     * 
     * 
     * 
     * 
     * An empty linked-list is simply [].
     *
     * @return a string representation of the linked-list's keys
     */
    public String toString() {
        StringBuilder builder = new StringBuilder();
        
        builder.append("[");
        builder.append(songTitle);
        builder.append(", ");
        builder.append(songArtist);
        builder.append(", ");
        builder.append(songGenre);
        builder.append(", ");
        builder.append(songYear);
        builder.append("]");
        return builder.toString();
    }
    
    public void setHobbyInfo(DoublyLinkedList<Student> students)
    {
       /**
        * top row in the 2d array is the has heard number
        * bottom is the doesLike number;
        * 
        * column 1 for the hobby array is read, col 2 = art
        * col 3 = sports, col 4 = music
        * 
        * for the major array, col 1 = CS, col 2 = other engineering
        * col 3 = Math or CMDA, col 4 = other
        * 
        * for regon array, col 1 = Northeast
        * col 2 = SouthEast, col 3 = rest of US,
        * col 4 = outside US
        */
       String studentHobby;
       String studentMajor;
       String studentRegion;
       int hasHeard;
       int doesLike;
       Student student;
       for (int i = 0; i < students.size(); i++ )
       {
           student = students.get(i);
           studentHobby = student.getHobby();
           studentMajor = student.getMajor();
           studentRegion = student.getRegion();
           hasHeard = student.getHasHeard().get(songNumber);
           doesLike = student.getDoesLike().get(songNumber);
           this.hobbySort(studentHobby, hasHeard, doesLike);
           this.majorSort(studentHobby, hasHeard, doesLike);
           this.regionSort(studentHobby, hasHeard, doesLike);
          
       }
       
    }
    
    /**
     * sets student data for hobby sort
     */
    private void hobbySort(String hobby, int heard, int like)
    {
        if (hobby.equals("read"))
        {
            hobbyInfo[1][1] = hobbyInfo[1][1] + heard;
            hobbyInfo[2][1] = hobbyInfo[2][1] + like;
        }
        else if (hobby.equals("art"))
        {
            hobbyInfo[1][2] = hobbyInfo[1][2] + heard;
            hobbyInfo[2][2] = hobbyInfo[2][2] + like;
        }
        else if (hobby.equals("sports"))
        {
            hobbyInfo[1][3] = hobbyInfo[1][3] + heard;
            hobbyInfo[2][3] = hobbyInfo[2][3] + like;
        }
        else if (hobby.equals("music"))
        {
            hobbyInfo[1][4] = hobbyInfo[1][4] + heard;
            hobbyInfo[2][4] = hobbyInfo[2][4] + like;   
        }
    }
    
    /**
     * sets student major data for  sort
     */
    private void majorSort(String major, int heard, int like)
    {
        if (major.equals("Computer Science"))
        {
            majorInfo[1][1] = majorInfo[1][1] + heard;
            majorInfo[2][1] = majorInfo[2][1] + like;
        }
        else if (major.equals("Other Engineering"))
        {
            majorInfo[1][2] = majorInfo[1][2] + heard;
            majorInfo[2][2] = majorInfo[2][2] + like;
        }
        else if (major.equals("MATH or CMDA"))
        {
            majorInfo[1][3] = majorInfo[1][3] + heard;
            majorInfo[2][3] = majorInfo[2][3] + like;
        }
        else if (major.equals("Other"))
        {
            majorInfo[1][4] = majorInfo[1][4] + heard;
            majorInfo[2][4] = majorInfo[2][4] + like;   
        }
    }
    
    
    /**
     * sets student data for region sort
     */
    private void regionSort(String region, int heard, int like)
    {
        if (region.equals("Northeast US"))
        {
            regionInfo[1][1] = regionInfo[1][1] + heard;
            regionInfo[2][1] = regionInfo[2][1] + like;
        }
        else if (region.equals("Southeast US"))
        {
            regionInfo[1][2] = regionInfo[1][2] + heard;
            regionInfo[2][2] = regionInfo[2][2] + like;
        }
        else if (region.equals("the rest of US"))
        {
            regionInfo[1][3] = regionInfo[1][3] + heard;
            regionInfo[2][3] = regionInfo[2][3] + like;
        }
        else if (region.equals("outside the US"))
        {
            regionInfo[1][4] = regionInfo[1][4] + heard;
            regionInfo[2][4] = regionInfo[2][4] + like;   
        }
    }
    
    /**
     * returns hobbyData
     */
    public int[][] getHobbyInfo()
    {
       return hobbyInfo; 
    }
    
    /**
     * returns majorData
     */
    public int[][] getMajorInfo()
    {
       return majorInfo; 
    }
    
    /**
     * returns regionData
     */
    public int[][] getRegionInfo()
    {
       return regionInfo; 
    }

}
