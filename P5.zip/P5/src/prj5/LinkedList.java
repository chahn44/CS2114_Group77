package prj5;

public interface LinkedList<T> {
    
    public void add(T object);
    
    public void add(int index, T object);
    
    public boolean remove(T object);
    
    public boolean remove(int index, T object);
    
    public T get(int index);
    
    public void clear();
    
    public int size();

    public boolean isEmpty();
    
    public Object[] toArray();

}
