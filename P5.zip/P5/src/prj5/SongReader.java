package prj5;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author Johnny
 *
 */
public class SongReader {
    //Fields
    private Scanner scanner;
    private DoublyLinkedList<Song> songList;
    private Song currentSong;
    
    /**
     * constructor, sets up scanner
     * @param id = file name to read song data from
     * @throws FileNotFoundException 
     */
    public SongReader(String id) 
    {
        try {
            scanner = new Scanner(new File(id));
        }
        catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        songList = new DoublyLinkedList<Song>();
    }
    
    /**
     * reads songs from text file and stores it in
     * a doubly linked list
     */
    public void readSongs()
    {
        String line;
        String title;
        String artist; 
        String genre;
        int year;
        String[] parse; 
        int number = 0;
        
        while (scanner.hasNextLine())
        {
            line = scanner.nextLine();
            parse = line.split(",");
            title = parse[0];
            artist = parse[1];
            year = Integer.parseInt(parse[2]);
            genre = parse[3];
            currentSong = new Song(title, genre, year, artist, number);
            songList.addToBack(currentSong);
            number++;
        }
    }
    
    /**
     * returns song list
     * @precondition = readSongs must be called first
     * @return = song list
     */
    public DoublyLinkedList<Song> getList()
    {
        return songList;
    }

}
