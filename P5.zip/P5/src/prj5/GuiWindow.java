package prj5;

import java.awt.Color;
import CS2114.Button;
import CS2114.Shape;
import CS2114.TextShape;
import CS2114.Window;
import CS2114.WindowSide;
import java.util.ArrayList;

public class GuiWindow {
    private DoublyLinkedList<Song> songs;
    private Window window;

    private Shape legend;
    private TextShape legendTitle;
    private TextShape listOne;
    private TextShape listTwo;
    private TextShape listThree;
    private TextShape listFour;
    private TextShape songTitle;
    private TextShape heard;
    private TextShape liked;
    private Shape bar;

    private Button next;
    private Button previous;
    private Button hobby;
    private Button major;
    private Button region;
    private Button title;
    private Button artist;
    private Button genre;
    private Button date;
    private Button quit;

    private int clicked;
    private int currentNum;
    private String cat;
    private Boolean lastPage;


    /**
     * Constructor that initializes the GlyphGenerator, the SongList, the
     * window, the legend, and the buttons
     */
    public GuiWindow(DoublyLinkedList<Song> list) {

        songs = list;
        window = new Window();
        window.setSize(1000, 1000);

        clicked = 0;
        currentNum = 0;
        cat = "title";
        lastPage = false;

        this.addLegend();

        previous = new Button("Previous");
        window.addButton(previous, WindowSide.NORTH);
        previous.onClick(this, "clickedPrevious");

        artist = new Button("Sort by Artist Name");
        window.addButton(artist, WindowSide.NORTH);
        artist.onClick(this, "clickedArtist");

        title = new Button("Sort by Song Title");
        window.addButton(title, WindowSide.NORTH);
        title.onClick(this, "clickedTitle");

        date = new Button("Sort by Release Year");
        window.addButton(date, WindowSide.NORTH);
        date.onClick(this, "clickedDate");

        genre = new Button("Sort by Genre");
        window.addButton(genre, WindowSide.NORTH);
        genre.onClick(this, "clickedGenre");

        next = new Button("Next");
        window.addButton(next, WindowSide.NORTH);
        next.onClick(this, "clickedNext");

        hobby = new Button("Represent Hobby");
        window.addButton(hobby, WindowSide.SOUTH);
        hobby.onClick(this, "clickedHobby");

        major = new Button("Represent Major");
        window.addButton(major, WindowSide.SOUTH);
        major.onClick(this, "clickedMajor");

        region = new Button("Represent Region");
        window.addButton(region, WindowSide.SOUTH);
        region.onClick(this, "clickedState");

        quit = new Button("Quit");
        window.addButton(quit, WindowSide.SOUTH);
        quit.onClick(this, "clickedQuit");
    }


    /**
     * Gets the window field
     * 
     * @return window the window field
     */
    public Window getWindow() {
        return window;
    }


    /**
     * Shows the next set of glyphs on the window
     * 
     * @param source
     *            the button clicked
     */
    public void clickedNext(Button source) {

        if (songs.size() > currentNum + 9) {
            currentNum += 9;
        }
        if (currentNum + 9 > songs.size()) {
            lastPage = true;
        }

        window.removeAllShapes();
        this.addLegend();
        this.addTitles(clicked);
        this.addGlyphs(cat);

        if (cat == "state") {
            this.updateLegendText(Category.region);
        }
        if (cat == "major") {
            this.updateLegendText(Category.major);
        }
        if (cat == "hobby") {
            this.updateLegendText(Category.hobby);
        }
    }


    /**
     * Shows the previous set of glyphs on the window
     * 
     * @param source
     *            the button clicked
     */
    public void clickedPrevious(Button source) {

        if (currentNum != 0) {
            currentNum -= 9;
        }
        if (currentNum + 9 <= songs.size()) {
            lastPage = false;
        }
        window.removeAllShapes();
        this.addLegend();
        this.addTitles(clicked);
        this.addGlyphs(cat);

        if (cat == "region") {
            this.updateLegendText(Category.region);
        }
        if (cat == "major") {
            this.updateLegendText(Category.major);
        }
        if (cat == "hobby") {
            this.updateLegendText(Category.hobby);
        }
    }


    /**
     * Closes the window
     * 
     * @param source
     *            the button clicked
     */
    public void clickedQuit(Button source) {
        System.exit(0);
    }


    /**
     * Represents the glyphs by hobby, and updates the legend
     * 
     * @param source
     *            the button clicked
     */
    public void clickedHobby(Button source) {

        window.removeAllShapes();
        this.addLegend();
        this.updateLegendText(Category.hobby);
        this.addTitles(clicked);
        cat = "hobby";
        this.addGlyphs("hobby");
    }


    /**
     * Represents the glyphs by major, and updates the legend
     * 
     * @param source
     *            the button clicked
     */
    public void clickedMajor(Button source) {

        window.removeAllShapes();
        this.addLegend();
        this.updateLegendText(Category.major);
        this.addTitles(clicked);
        cat = "major";
        this.addGlyphs("major");

    }


    /**
     * Represents the glyphs by state, and updates the legend
     * 
     * @param source
     *            the button clicked
     */
    public void clickedState(Button source) {
        window.removeAllShapes();
        this.addLegend();
        this.updateLegendText(Category.region);
        this.addTitles(clicked);
        cat = "state";
        this.addGlyphs("state");
    }


    /**
     * Create Glyphs
     * 
     * @param type
     *            the glyphs to create
     */
    private void addGlyphs(String type) {

        GlyphListBuilder gen = new GlyphListBuilder(songs);
        ArrayList<Glyph> current = null;

        if (type == "state") {
            current = gen.createGlyphsByRegion();
            cat = "state";
        }

        if (type == "major") {
            current = gen.createGlyphsByMajor();
            cat = "major";
        }

        if (type == "hobby") {
            current = gen.createGlyphsByHobby();
            cat = "hobby";
        }

        int total = currentNum + 9;
        if (lastPage) {
            total = songs.size();
        }

        for (int i = currentNum; i < total; i++) {
            for (int j = 1; j < 5; j++) {
                Shape shape = current.get(i).getShapes()[j];
                shape.setX(143 + ((i % 3) * 279));
                shape.setY(145 + (j * 12) + (i % 9 / 3) * 300);
                window.addShape(shape);
            }
            for (int k = 5; k < 9; k++) {
                Shape shape = current.get(i).getShapes()[k];
                shape.setX(138 + ((i % 3) * 279) - shape.getWidth());
                shape.setY(145 + ((k - 4) * 12) + (i % 9 / 3) * 300);
                window.addShape(shape);
            }
        }
    }


    /**
     * Displays the songs sorted by title
     * 
     * @param source
     *            the button clicked
     */
    public void clickedTitle(Button source) {
        songs.sortByTitle(); // need a sorting method in song/songreader
        window.removeAllShapes();
        clicked = 0;
        this.addLegend();
        this.addTitles(clicked);
        this.addGlyphs(cat);

    }


    /**
     * Displays the songs sorted by artist
     * 
     * @param source
     *            the button clicked
     */
    public void clickedArtist(Button source) {
        songs.sortByArtist(); // need a sorting method in song/songreader
        window.removeAllShapes();
        clicked = 1;
        this.addLegend();
        this.addTitles(clicked);
        this.addGlyphs(cat);
    }


    /**
     * Displays the songs sorted by genre
     * 
     * @param source
     *            the button clicked
     */
    public void clickedGenre(Button source) {
        songs.sortByGenre(); // need a sorting method in song/songreader
        window.removeAllShapes();
        clicked = 2;
        this.addLegend();
        this.addTitles(clicked);
        this.addGlyphs(cat);
    }


    /**
     * Displays the songs sorted by date
     * 
     * @param source
     *            the button clicked
     */
    public void clickedDate(Button source) {
        songs.sortByDate(); // need a sorting method in song/songreader
        window.removeAllShapes();
        clicked = 3;
        this.addLegend();
        this.addTitles(clicked);
        this.addGlyphs(cat);

    }


    private void addTitles(int number) {

        int total = currentNum + 9;
        if (lastPage) {
            total = songs.size();
        }

        for (int i = currentNum; i < total; i++) {
            int x = 143 + ((i % 3) * 279) - 100;
            int y = 100 + (i % 9 / 3) * 300;
            Song current = songs.get(i);
            String str = "";
            String str2 = "";
            if (number == 0) {
                str = current.getTitle();
                str2 = "by: " + current.getArtist();
            }
            if (number == 1) {
                str = current.getTitle();
                str2 = "by: " + current.getArtist();
            }
            if (number == 2) {
                str = current.getTitle();
                str2 = "genre: " + current.getGenre();
            }
            if (number == 3) {
                str = current.getTitle();
                str2 = "release year: " + current.getYear();
            }
            TextShape titlePart1 = new TextShape(x, y - 10, str);
            TextShape titlePart2 = new TextShape(x, y + 10, str2);
            titlePart1.setBackgroundColor(Color.WHITE);
            titlePart2.setBackgroundColor(Color.WHITE);
            window.addShape(titlePart1);
            window.addShape(titlePart2);
        }
    }


    private void addLegend() {
        final int WIDTH = 120;
        final int HEIGHT = 210;
        final int GAP = 155;
        final int GAP2 = 20;
        final int GAP3 = 1;
        final int GAP4 = 15;
        final int HEARDX = 850;
        final int LIKEDX = 905;
        int x = window.getGraphPanelWidth() - WIDTH - GAP2;
        int y = window.getGraphPanelHeight() - HEIGHT - (GAP2 * 3);
        legend = new Shape(x, y, WIDTH, HEIGHT);
        legend.setBackgroundColor(Color.WHITE);
        legend.setForegroundColor(Color.BLACK);
        bar = new Shape(897, y + GAP, 3, 50);
        bar.setBackgroundColor(Color.BLACK);
        bar.setForegroundColor(Color.BLACK);
        window.addShape(bar);
        legendTitle = new TextShape(x + (GAP3 * 3), y + (GAP3 * 2),
            "Hobby Legend");
        legendTitle.setBackgroundColor(Color.WHITE);
        window.addShape(legendTitle);
        listOne = new TextShape(x + GAP3, y + GAP2, "read");
        listOne.setForegroundColor(Color.MAGENTA);
        listOne.setBackgroundColor(Color.WHITE);
        window.addShape(listOne);
        listTwo = new TextShape(x + GAP3, y + GAP2 + GAP4, "art");
        listTwo.setForegroundColor(Color.BLUE);
        listTwo.setBackgroundColor(Color.WHITE);
        window.addShape(listTwo);
        listThree = new TextShape(x + GAP3, y + GAP2 + (GAP4 * 2), "sports");
        listThree.setForegroundColor(Color.ORANGE);
        listThree.setBackgroundColor(Color.WHITE);
        window.addShape(listThree);
        listFour = new TextShape(x + GAP3, y + GAP2 + (GAP4 * 3), "music");
        listFour.setForegroundColor(Color.GREEN);
        listFour.setBackgroundColor(Color.WHITE);
        window.addShape(listFour);
        songTitle = new TextShape(x + (GAP3 * 3), y + (GAP2 * 5), "Song Title");
        songTitle.setBackgroundColor(Color.WHITE);
        window.addShape(songTitle);
        heard = new TextShape(HEARDX, y + GAP, "Heard");
        heard.setBackgroundColor(Color.WHITE);
        window.addShape(heard);
        liked = new TextShape(LIKEDX, y + GAP, "Likes");
        liked.setBackgroundColor(Color.WHITE);
        window.addShape(liked);
        window.addShape(legend);

        Shape vertical = new Shape(138, 145, 5, 83);
        vertical.setBackgroundColor(Color.BLACK);
        window.addShape(vertical);

        Shape vertical2 = new Shape(418, 145, 5, 83);
        vertical2.setBackgroundColor(Color.BLACK);
        window.addShape(vertical2);

        Shape vertical3 = new Shape(697, 145, 5, 83);
        vertical3.setBackgroundColor(Color.BLACK);
        window.addShape(vertical3);

        Shape vertical4 = new Shape(138, 435, 5, 83);
        vertical4.setBackgroundColor(Color.BLACK);
        window.addShape(vertical4);

        Shape vertical5 = new Shape(418, 435, 5, 83);
        vertical5.setBackgroundColor(Color.BLACK);
        window.addShape(vertical5);

        Shape vertical6 = new Shape(697, 435, 5, 83);
        vertical6.setBackgroundColor(Color.BLACK);
        window.addShape(vertical6);

        Shape vertical7 = new Shape(138, 726, 5, 83);
        vertical7.setBackgroundColor(Color.BLACK);
        window.addShape(vertical7);

        Shape vertical8 = new Shape(418, 726, 5, 83);
        vertical8.setBackgroundColor(Color.BLACK);
        window.addShape(vertical8);

        Shape vertical9 = new Shape(697, 726, 5, 83);
        vertical9.setBackgroundColor(Color.BLACK);
        window.addShape(vertical9);
    }


    /**
     * Updates the textShapes in the legend
     * 
     * @param represent
     *            the enumerator passed in
     */
    public void updateLegendText(Category ctegr) {
        if (ctegr == Category.hobby) {
            legendTitle.setText("Hobby Legend");
            listOne.setText("read");
            listTwo.setText("art");
            listThree.setText("sports");
            listFour.setText("music");
        }
        else if (ctegr == Category.major) {
            legendTitle.setText("Major Legend");
            listOne.setText("Computer Science");
            listTwo.setText("Other Engineering");
            listThree.setText("Math or CMDA");
            listFour.setText("Other");
        }
        else if (ctegr == Category.region) {
            legendTitle.setText("Region Legend");
            listOne.setText("Northeast");
            listTwo.setText("Southeast");
            listThree.setText("Rest of the US");
            listFour.setText("Outside of the US");
        }
    }
}
