package prj5;

import java.awt.Color;
import CS2114.Button;
import CS2114.Shape;
import CS2114.TextShape;
import CS2114.Window;
import CS2114.WindowSide;
import java.util.ArrayList;

public class GuiWindow {
    private DoublyLinkedList<Song> songs;
    private Window window;

    private Shape legend;
    private TextShape legendTitle;
    private TextShape listOne;
    private TextShape listTwo;
    private TextShape listThree;
    private TextShape listFour;
    private TextShape songTitle;
    private TextShape heard;
    private TextShape liked;
    private Shape bar;

    private Button next;
    private Button previous;
    private Button hobby;
    private Button major;
    private Button region;
    private Button title;
    private Button artist;
    private Button genre;
    private Button date;
    private Button quit;

    private int clicked;
    private int currentNum;
    private String cat;
    private Boolean lastPage;


    /**
     * Constructor that initializes the GlyphGenerator, the SongList, the
     * window, the legend, and the buttons
     */
    public GuiWindow(DoublyLinkedList<Song> list) {

        songs = list;
        window = new Window();
        window.setSize(1000, 1000);

        clicked = 0;
        currentNum = 0;
        cat = "title";
        lastPage = false;

        this.addLegend();

        previous = new Button("Previous");
        window.addButton(previous, WindowSide.NORTH);
        previous.onClick(this, "clickedPrevious");

        artist = new Button("Sort by Artist Name");
        window.addButton(artist, WindowSide.NORTH);
        artist.onClick(this, "clickedArtist");

        title = new Button("Sort by Song Title");
        window.addButton(title, WindowSide.NORTH);
        title.onClick(this, "clickedTitle");

        date = new Button("Sort by Release Year");
        window.addButton(date, WindowSide.NORTH);
        date.onClick(this, "clickedDate");

        genre = new Button("Sort by Genre");
        window.addButton(genre, WindowSide.NORTH);
        genre.onClick(this, "clickedGenre");

        next = new Button("Next");
        window.addButton(next, WindowSide.NORTH);
        next.onClick(this, "clickedNext");

        hobby = new Button("Represent Hobby");
        window.addButton(hobby, WindowSide.SOUTH);
        hobby.onClick(this, "clickedHobby");

        major = new Button("Represent Major");
        window.addButton(major, WindowSide.SOUTH);
        major.onClick(this, "clickedMajor");

        region = new Button("Represent Region");
        window.addButton(region, WindowSide.SOUTH);
        region.onClick(this, "clickedState");

        quit = new Button("Quit");
        window.addButton(quit, WindowSide.SOUTH);
        quit.onClick(this, "clickedQuit");
    }


    /**
     * Gets the window
     * 
     * @return window
     *         the window
     */
    public Window getWindow() {
        return window;
    }


    /**
     * Shows the next set of glyphs on the window
     * 
     * @param benjamin
     *            the button clicked
     */
    public void clickedNext(Button benjamin) {

        if (songs.size() > currentNum + 9) {
            currentNum += 9;
        }
        if (currentNum + 9 > songs.size()) {
            lastPage = true;
        }

        window.removeAllShapes();
        this.addLegend();
        this.addTitles(clicked);
        this.addGlyphs(cat);

        if (cat == "state") {
            this.updateLegendText(Category.region);
        }
        if (cat == "major") {
            this.updateLegendText(Category.major);
        }
        if (cat == "hobby") {
            this.updateLegendText(Category.hobby);
        }
    }


    /**
     * Shows the previous set of glyphs on the window
     * 
     * @param benjamin
     *            the button clicked
     */
    public void clickedPrevious(Button benjamin) {

        if (currentNum != 0) {
            currentNum -= 9;
        }
        if (currentNum + 9 <= songs.size()) {
            lastPage = false;
        }
        window.removeAllShapes();
        this.addLegend();
        this.addTitles(clicked);
        this.addGlyphs(cat);

        if (cat == "region") {
            this.updateLegendText(Category.region);
        }
        if (cat == "major") {
            this.updateLegendText(Category.major);
        }
        if (cat == "hobby") {
            this.updateLegendText(Category.hobby);
        }
    }


    /**
     * Closes the window
     * 
     * @param benjamin
     *            the button clicked
     */
    public void clickedQuit(Button benjamin) {
        System.exit(0);
    }


    /**
     * Represents the glyphs by hobby, and updates the legend
     * 
     * @param benjamin
     *            the button clicked
     */
    public void clickedHobby(Button benjamin) {

        window.removeAllShapes();
        this.addLegend();
        this.updateLegendText(Category.hobby);
        this.addTitles(clicked);
        cat = "hobby";
        this.addGlyphs("hobby");
    }


    /**
     * Represents the glyphs by major, and updates the legend
     * 
     * @param benjamin
     *            the button clicked
     */
    public void clickedMajor(Button benjamin) {

        window.removeAllShapes();
        this.addLegend();
        this.updateLegendText(Category.major);
        this.addTitles(clicked);
        cat = "major";
        this.addGlyphs("major");

    }


    /**
     * Represents the glyphs by state, and updates the legend
     * 
     * @param benjamin
     *            the button clicked
     */
    public void clickedState(Button benjamin) {
        window.removeAllShapes();
        this.addLegend();
        this.updateLegendText(Category.region);
        this.addTitles(clicked);
        cat = "state";
        this.addGlyphs("state");
    }


    /**
     * Create Glyphs
     * 
     * @param type
     *            the glyphs to create
     */
    private void addGlyphs(String type) {

        GlyphListBuilder create = new GlyphListBuilder(songs);
        ArrayList<Glyph> current = null;

        if (type == "state") {
            current = create.createGlyphsByRegion();
            cat = "state";
        }

        if (type == "major") {
            current = create.createGlyphsByMajor();
            cat = "major";
        }

        if (type == "hobby") {
            current = create.createGlyphsByHobby();
            cat = "hobby";
        }

        int total = currentNum + 9;
        if (lastPage) {
            total = songs.size();
        }

        for (int i = currentNum; i < total; i++) {
            for (int j = 1; j < 5; j++) {
                Shape shape = current.get(i).getShapes()[j];
                shape.setX(143 + ((i % 3) * 279));
                shape.setY(145 + (j * 12) + (i % 9 / 3) * 300);
                window.addShape(shape);
            }
            for (int k = 5; k < 9; k++) {
                Shape shape = current.get(i).getShapes()[k];
                shape.setX(138 + ((i % 3) * 279) - shape.getWidth());
                shape.setY(145 + ((k - 4) * 12) + (i % 9 / 3) * 300);
                window.addShape(shape);
            }
        }
    }


    /**
     * Displays the songs sorted by title
     * 
     * @param source
     *            the button clicked
     */
    public void clickedTitle(Button source) {
        songs.sortByTitle(); // need a sorting method in song/songreader
        window.removeAllShapes();
        clicked = 0;
        this.addLegend();
        this.addTitles(clicked);
        this.addGlyphs(cat);

    }


    /**
     * Displays the songs sorted by artist
     * 
     * @param source
     *            the button clicked
     */
    public void clickedArtist(Button source) {
        songs.sortByArtist(); // need a sorting method in song/songreader
        window.removeAllShapes();
        clicked = 1;
        this.addLegend();
        this.addTitles(clicked);
        this.addGlyphs(cat);
    }


    /**
     * Displays the songs sorted by genre
     * 
     * @param source
     *            the button clicked
     */
    public void clickedGenre(Button source) {
        songs.sortByGenre(); // need a sorting method in song/songreader
        window.removeAllShapes();
        clicked = 2;
        this.addLegend();
        this.addTitles(clicked);
        this.addGlyphs(cat);
    }


    /**
     * Displays the songs sorted by date
     * 
     * @param source
     *            the button clicked
     */
    public void clickedDate(Button source) {
        songs.sortByDate(); // need a sorting method in song/songreader
        window.removeAllShapes();
        clicked = 3;
        this.addLegend();
        this.addTitles(clicked);
        this.addGlyphs(cat);

    }


    /**
     * Adds titles for the categories
     * 
     * @param number
     * 
     */
    private void addTitles(int number) {

        int total = currentNum + 9;
        if (lastPage) {
            total = songs.size();
        }

        for (int i = currentNum; i < total; i++) {
            int x = 143 + ((i % 3) * 279) - 100;
            int y = 100 + (i % 9 / 3) * 300;
            Song current = songs.get(i);
            String str = "";
            String strTwo = "";
            if (number == 0) {
                str = current.getTitle();
                strTwo = "by: " + current.getArtist();
            }
            if (number == 1) {
                str = current.getTitle();
                strTwo = "by: " + current.getArtist();
            }
            if (number == 2) {
                str = current.getTitle();
                strTwo = "genre: " + current.getGenre();
            }
            if (number == 3) {
                str = current.getTitle();
                strTwo = "release year: " + current.getYear();
            }
            TextShape titlePart1 = new TextShape(x, y - 10, str);
            TextShape titlePart2 = new TextShape(x, y + 10, str2);
            titlePart1.setBackgroundColor(Color.WHITE);
            titlePart2.setBackgroundColor(Color.WHITE);
            window.addShape(titlePart1);
            window.addShape(titlePart2);
        }
    }


    private void addLegend() {
        final int WIDTH = 120;
        final int HEIGHT = 210;
        final int setOne = 155;
        final int setTwo = 20;
        final int setThree = 1;
        final int setFour = 15;
        final int HEARDX = 850;
        final int LIKEDX = 905;
        int x = window.getGraphPanelWidth() - WIDTH - setTwo;
        int y = window.getGraphPanelHeight() - HEIGHT - (setTwo * 3);
        legend = new Shape(x, y, WIDTH, HEIGHT);
        legend.setBackgroundColor(Color.WHITE);
        legend.setForegroundColor(Color.BLACK);
        bar = new Shape(897, y + setOne, 3, 50);
        bar.setBackgroundColor(Color.BLACK);
        bar.setForegroundColor(Color.BLACK);
        window.addShape(bar);
        legendTitle = new TextShape(x + (setThree * 3), y + (setThree * 2),
            "Hobby");
        legendTitle.setBackgroundColor(Color.WHITE);
        window.addShape(legendTitle);
        listOne = new TextShape(x + setThree, y + setTwo, "read");
        listOne.setForegroundColor(Color.MAGENTA);
        listOne.setBackgroundColor(Color.WHITE);
        window.addShape(listOne);
        listTwo = new TextShape(x + setThree, y + setTwo + setFour, "art");
        listTwo.setForegroundColor(Color.BLUE);
        listTwo.setBackgroundColor(Color.WHITE);
        window.addShape(listTwo);
        listThree = new TextShape(x + setThree, y + setTwo + (setFour * 2), "sports");
        listThree.setForegroundColor(Color.ORANGE);
        listThree.setBackgroundColor(Color.WHITE);
        window.addShape(listThree);
        listFour = new TextShape(x + setThree, y + setTwo + (setFour * 3), "music");
        listFour.setForegroundColor(Color.GREEN);
        listFour.setBackgroundColor(Color.WHITE);
        window.addShape(listFour);
        songTitle = new TextShape(x + (setThree * 3), y + (setTwo * 5), "Song Title");
        songTitle.setBackgroundColor(Color.WHITE);
        window.addShape(songTitle);
        heard = new TextShape(HEARDX, y + setOne, "Heard");
        heard.setBackgroundColor(Color.WHITE);
        window.addShape(heard);
        liked = new TextShape(LIKEDX, y + setOne, "Liked");
        liked.setBackgroundColor(Color.WHITE);
        window.addShape(liked);
        window.addShape(legend);

        Shape planeOne = new Shape(138, 145, 5, 83);
        planeOne.setBackgroundColor(Color.BLACK);
        window.addShape(planeOne);

        Shape planeTwo = new Shape(418, 145, 5, 83);
        planeTwo.setBackgroundColor(Color.BLACK);
        window.addShape(planeTwo);

        Shape planeThree = new Shape(697, 145, 5, 83);
        planeThree.setBackgroundColor(Color.BLACK);
        window.addShape(planeThree);

        Shape planeFour = new Shape(138, 435, 5, 83);
        planeFour.setBackgroundColor(Color.BLACK);
        window.addShape(planeFour);

        Shape planeFive = new Shape(418, 435, 5, 83);
        planeFive.setBackgroundColor(Color.BLACK);
        window.addShape(planeFive);

        Shape planeSix = new Shape(697, 435, 5, 83);
        planeSix.setBackgroundColor(Color.BLACK);
        window.addShape(planeSix);

        Shape planeSeven = new Shape(138, 726, 5, 83);
        planeSeven.setBackgroundColor(Color.BLACK);
        window.addShape(planeSeven);

        Shape planeEight = new Shape(418, 726, 5, 83);
        planeEight.setBackgroundColor(Color.BLACK);
        window.addShape(planeEight);

        Shape planeNine = new Shape(697, 726, 5, 83);
        planeNine.setBackgroundColor(Color.BLACK);
        window.addShape(planeNine);
    }


    /**
     * Updates the text in the legend
     * 
     * @param represent
     *            the enumerator passed in
     */
    public void updateLegendText(Category ctegr) {
        if (ctegr == Category.hobby) {
            legendTitle.setText("Hobby");
            listOne.setText("read");
            listTwo.setText("art");
            listThree.setText("sports");
            listFour.setText("music");
        }
        else if (ctegr == Category.major) {
            legendTitle.setText("Major");
            listOne.setText("Computer Science");
            listTwo.setText("Other Engineering");
            listThree.setText("Math or CMDA");
            listFour.setText("Other");
        }
        else if (ctegr == Category.region) {
            legendTitle.setText("Region");
            listOne.setText("Northeast");
            listTwo.setText("Southeast");
            listThree.setText("Rest of the US");
            listFour.setText("Outside of the US");
        }
    }
}
