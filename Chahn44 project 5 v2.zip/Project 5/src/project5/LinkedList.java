package project5;

public interface LinkedList<T> {
    
    public void addToFront(T object);
    
    public void addToBack(T object);
    
    public void add(int index, T object);
    
    public boolean remove(T object);
    
    public boolean remove(int index);
    
    public T get(int index);
    
    public void clear();
    
    public int size();

    public boolean isEmpty();
    
    public Object[] toArray();

}
