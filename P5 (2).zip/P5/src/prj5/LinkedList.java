package prj5;

public interface LinkedList<T> {
    
    /**
     * adds a new item to the front of the list
     * 
     * @param item
     *            the item being added to the front of the list
     */
    public void addToFront(T object);
    
    /**
     * adds a new item to the back of the list
     * 
     * @param item
     *            the item being added to the back of the list
     */
    public void addToBack(T object);
    
    /**
     * adds a new item into the list at a specified index
     * 
     * @param item
     *            the item being added to the back of the list
     * @param index
     *            the index position where the new item is being added
     */
    public void add(int index, T object);
    
    /**
     * removes a certain specified item from the list
     * 
     * @param item
     *            the item being removed
     * @return true if the item is properly removed
     */
    public boolean remove(T object);
    
    /**
     * removes the item at the specified index
     * 
     * @param index
     *            the index of the item that is being removed
     * @return true if the item is properly removed
     */
    public boolean remove(int index);
    
    /**
     * gets and returns the item at a specified index
     * 
     * @param index
     *            the index of the wanted item
     * @return the value of the item at the specified index
     */
    public T get(int index);
    
    /**
     * clears the doublyLinkedList of all values
     */
    public void clear();
    
    /**
     * returns the size (number of entries) of the doublyLinkedList
     * 
     * @return size
     */
    public int size();

    /**
     * determines whether the list is empty or not empty
     * 
     * @return true if the list is empty
     */
    public boolean isEmpty();
    
    /**
     * translates all items in the doubly linked list into an array for easier
     * manipulation and calculation
     * 
     * @return an array of the items in the list
     */
    public Object[] toArray();

}
