package prj5;



public class InputReader {
    
} 
