package prj5;

/**
 * @author Johnny Jaffee (jjaffee)
 * @version (2018.04.09)
 */
public class SongReaderTest extends student.TestCase {
// Fields
    private String file;
    private SongReader songReader;


    /**
     * set up, instantiates fields
     */
    public void setUp() {
        file = "SongListTest1.csv";
        songReader = new SongReader(file);
    }


    /**
     * tests methods used in SongReader by checking
     * that all the stored fields for song objects are correct
     */
    public void testSongRead() {

        SongReader noFile = new SongReader("not a file");

        String err = "File Not Found";
        assertFuzzyEquals(err, systemOut().getHistory());

        songReader.readSongs();
        DoublyLinkedList<Song> songs = songReader.getList();
        assertEquals(songs.size(), 5);
        assertEquals(songs.get(0).getClass(), Song.class);
        assertEquals(songs.get(0).getTitle(), "All These Things I've Done");
        assertEquals(songs.get(0).getArtist(), "The Killers");
        assertEquals(songs.get(0).getYear(), 2005);
        assertEquals(songs.get(0).getGenre(), "alternative");

        assertEquals(songs.get(4).getTitle(), "Another One Bites the Dust");
        assertEquals(songs.get(4).getArtist(), "Queen");
        assertEquals(songs.get(4).getYear(), 1980);
        assertEquals(songs.get(4).getGenre(), "disco");

    }
}
