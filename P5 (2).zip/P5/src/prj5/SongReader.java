// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept
// the actions of those who do.
// -- Your name (jjaffee)

/**
 * the following class reads song data from a comma delimited
 * csv file and stores this data as a doublylinkedlist of songs
 * assumed input file has one header line
 */
package prj5;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * @author Johnny Jaffee (jjaffee)
 * @version (2018.04.09)
 */
public class SongReader {
    // Fields
    private Scanner scanner;
    private DoublyLinkedList<Song> songList;
    private Song currentSong;


    /**
     * constructor, sets up scanner
     * 
     * @param id
     *            = file name to read song data from
     * @throws FileNotFoundException
     */
    public SongReader(String id) {
        try {
            scanner = new Scanner(new File(id));
        }
        catch (FileNotFoundException e) {
            // Auto-generated catch block
            e.printStackTrace();
        }
        songList = new DoublyLinkedList<Song>();
    }


    /**
     * reads songs from text file and stores it in
     * a doubly linked list
     */
    public void readSongs() {
        String line;
        String title;
        String artist;
        String genre;
        int year;
        String[] parse;
        int number = 0;
        line = scanner.nextLine();
        while (scanner.hasNextLine()) {
            line = scanner.nextLine();
            parse = line.split(",", -1);

            title = parse[0];
            artist = parse[1];
            year = Integer.parseInt(parse[2]);
            genre = parse[3];
            currentSong = new Song(title, genre, year, artist, number);
            songList.addToBack(currentSong);
            number++;
        }
    }


    /**
     * returns song list
     * 
     * @precondition = readSongs must be called first
     * @return = song list
     */
    public DoublyLinkedList<Song> getList() {
        return songList;
    }

}
