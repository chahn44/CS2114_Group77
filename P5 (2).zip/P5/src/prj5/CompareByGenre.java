package prj5;

import java.util.Comparator;

public class CompareByGenre implements Comparator<Glyph>{
    
    public CompareByGenre() {
        // blank
    }
    
    /**
     * returns a value less than 0 if the argument is a string lexicographically
     * greater than this string
     * returns 0 if equals
     * returns a value greater than 0 if argument is lexicographically less than
     * this string
     * 
     * @param glyph1
     * @param glyph2
     * @return
     */
    public int compare(Glyph glyph1, Glyph glyph2) {
        return glyph1.getSong().getGenre().compareTo(glyph2.getSong()
            .getGenre());
    }

}
