package project5;

import java.util.Iterator;
import student.TestCase;

public class DoublyLinkedListTest extends TestCase {

    DoublyLinkedList<String> list1;


    /**
     * sets up for the test cases
     */
    public void setUp() {
        list1 = new DoublyLinkedList<String>();

    }


    /**
     * tests to see if the add method can take an index and T value and input
     * the value into the list at index I
     */
    public void testAdd() {

        Iterator<String> iter = list1.iterator();

        assertEquals(0, list1.size());
        list1.add(0, "Item1");
        assertEquals(1, list1.size()); // tests that size increases
        assertEquals("Item1", iter.next()); // and item is added at index 0

        Iterator<String> iter2 = list1.iterator();

        list1.add(1, "Item2");
        list1.add(1, "Item1.5"); // tests to make sure item at index 1 is now
                                 // bumped to index 2 in order to insert Item1.5
                                 // at index 1
        assertEquals("Item1", iter2.next());
        assertEquals("Item1.5", iter2.next());
        assertEquals("Item2", iter2.next());

    }


    /**
     * tests to see if the add method throws and index out of bounds error if
     * the index is less than zero or above the length of the list
     */
    public void testAddException() {

        Exception exception = null;
        try {
            list1.add(10, "item1");
            ;
            fail("next is not throwing an exception when it should");
        }
        catch (Exception e) {
            exception = e;
        }
        assertTrue("next is throwing the wrong type of exceptions",
            exception instanceof IndexOutOfBoundsException);

    }


    /**
     * tests that addToBack properly adds an item to the end of the list and
     * increases size
     */
    public void testAddToBack() {
        list1.addToBack("itemFirst");
        assertEquals(1, list1.size());
        list1.addToBack("itemMiddle");
        assertEquals(2, list1.size());
        list1.addToBack("itemLast");
        assertEquals("itemFirst", list1.get(0));
        assertEquals("itemMiddle", list1.get(1));
        assertEquals("itemLast", list1.get(2));
    }


    /**
     * tests that addToFront properly adds an item to the end of the list and
     * increases size
     */
    public void testAddToFront() {
        list1.addToFront("itemLast");
        assertEquals(1, list1.size());
        list1.addToFront("itemMiddle");
        assertEquals(2, list1.size());
        list1.addToFront("itemFirst");
        assertEquals("itemFirst", list1.get(0));
        assertEquals("itemMiddle", list1.get(1));
        assertEquals("itemLast", list1.get(2));

    }


    /**
     * tests that clear removes all items from the list and sets size to 0;
     */
    public void testClear() {
        assertEquals(0, list1.size());
        list1.clear();
        assertEquals(0, list1.size());

        list1.add(0, "item1");
        list1.add(1, "item2");
        list1.add(2, "item3");

        assertEquals(3, list1.size());
        list1.clear();
        assertEquals(0, list1.size());
    }


    /**
     * tests that get returns the item at a specified index
     */
    public void testGet() {
        list1.add(0, "item1");
        list1.add(1, "item2");
        list1.add(2, "item3");
        assertEquals("item1", list1.get(0));
        assertEquals("item2", list1.get(1));
        assertEquals("item3", list1.get(2));
    }


    /**
     * tests that get throws in indexOutOfBounds exception when the index is not
     * within the list size
     */
    public void testGetException() {
        list1.add(0, "item1");
        list1.add(1, "item2");
        list1.add(2, "item3");

        Exception exception = null;
        try {
            list1.get(10);
            ;
            fail("next is not throwing an exception when it should");
        }
        catch (Exception e) {
            exception = e;
        }
        assertTrue("next is throwing the wrong type of exceptions",
            exception instanceof IndexOutOfBoundsException);
    }


    /**
     * tests that isEmpty returns true if the list is empty and false if the
     * list is not empty
     */
    public void testIsEmpty() {
        assertTrue(list1.isEmpty());
        list1.add(0, "item1");
        assertFalse(list1.isEmpty());
    }


    /**
     * tests that remove, with the parameter int removes the item at the
     * specified int and returns true. If the index value doesn't exist in the
     * list it will return false
     */
    public void testRemoveInt() {
        list1.add(0, "item1");
        list1.add(1, "item2");
        list1.add(2, "item3");
        assertEquals(3, list1.size());

        assertEquals("item1", list1.get(0)); // removing first
        assertTrue(list1.remove(0));
        assertEquals(2, list1.size());
        assertEquals("item2", list1.get(0));

        list1.addToFront("item1"); // adds first back
        assertEquals(3, list1.size());

        assertEquals("item2", list1.get(1)); // removing middle
        assertTrue(list1.remove(1));
        assertEquals(2, list1.size());
        assertEquals("item3", list1.get(1));

        list1.add(1, "item2"); // adds middle back
        assertEquals(3, list1.size());

        assertEquals("item3", list1.get(2)); // removing last
        assertTrue(list1.remove(2));

        assertFalse(list1.remove(7)); // removing a nonexistent
    }


    /**
     * tests that remove, with the parameter T item removes the T item and
     * returns true. If the T item value doesn't exist in the
     * list it will return false
     */
    public void testRemoveT() {
        list1.add(0, "item1");
        list1.add(1, "item2");
        list1.add(2, "item3");
        assertEquals(3, list1.size());

        assertEquals("item1", list1.get(0)); // removing first
        assertTrue(list1.remove("item1"));
        assertEquals(2, list1.size());
        assertEquals("item2", list1.get(0));

        list1.addToFront("item1"); // adds first back
        assertEquals(3, list1.size());

        assertEquals("item2", list1.get(1)); // removing middle
        assertTrue(list1.remove("item2"));
        assertEquals(2, list1.size());
        assertEquals("item3", list1.get(1));

        list1.add(1, "item2"); // adds middle back
        assertEquals(3, list1.size());

        assertEquals("item3", list1.get(2)); // removing last
        assertTrue(list1.remove("item3"));

        assertFalse(list1.remove("item5")); // removing a nonexistent
    }


    /**
     * tests that the size method returns the number of items in the list
     */
    public void testSize() {
        assertEquals(0, list1.size());
        list1.add(0, "item1");
        assertEquals(1, list1.size());
        list1.add(1, "item2");
        assertEquals(2, list1.size());
        list1.add(2, "item3");
        assertEquals(3, list1.size());
    }


    /**
     * tests that the method toArray properly returns an array of the items in
     * the list
     * 
     * note to self: it doesn't, and this test doesn't work
     */
    public void testToArray() {
        // String[] emptyArray = new String[] {};
        // String[] filledArray = new String[]{"item1", "item2", "item3"};

        assertEquals(0, list1.toArray().length);
        list1.add(0, "item1");
        list1.add(1, "item2");
        list1.add(2, "item3");
        assertEquals(3, list1.toArray().length);

    }
}
