package project5;

import student.TestCase;

public class CompareByAllTests extends TestCase{
    
    /**
     * sets up for test methods
     */
    {
        
    }

}
