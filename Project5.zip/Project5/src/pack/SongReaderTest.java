/**
 * 
 */
package pack;

/**
 * @author Johnny
 *
 */
public class SongReaderTest extends student.TestCase {
//Fields
    private String file;
    private SongReader songReader;
    
    
    /**
     * set up, instantiates fields
     */
    public void setUp()
    {
        file = "SongListTest1.csv";
        songReader = new SongReader(file);
    }
    
    /**
     * tests methods used in SongReader
     */
    public void testSongRead()
    {
        songReader.readSongs();
        DoublyLinkedList<Song> songs = songReader.getList();
        assertEquals(songs.size(), 5);
        assertEquals(songs.get(0).getClass(), Song.class);
        assertEquals(songs.get(0).getTitle(), "All These Things I've Done");
        assertEquals(songs.get(0).getArtist(), "The Killers");
        assertEquals(songs.get(0).getYear(), 2005 );
        assertEquals(songs.get(0).getGenre(), "alternative");
        
        
        assertEquals(songs.get(4).getTitle(), "Another One Bites the Dust");
        assertEquals(songs.get(4).getArtist(), "Queen");
        assertEquals(songs.get(4).getYear(), 1980 );
        assertEquals(songs.get(4).getGenre(), "disco");
        
    }
}
