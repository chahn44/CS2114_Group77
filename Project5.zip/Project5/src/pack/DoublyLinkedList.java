package pack;

import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

/**
 * This class allows the user to create doubly linked lists with an underlying
 * node structure (in the form of an inner node class) and an inner class
 * iterator for better future traversal of the list
 *
 * @author Charlotte Hahn <chahn44>
 * @version 4/9/2018
 * @param <T>
 */
public class DoublyLinkedList<T> implements LinkedList<T> {

    private int size;
    private Node head;
    private Node tail;


    /**
     * constructor for the DoublyLinkedList class
     */
    public DoublyLinkedList() {
        this.size = 0;
        this.head = new Node();
        this.tail = new Node();
        this.head.linkWith(this.tail);
    }


    /**
     * adds a new item into the list at a specified index
     * 
     * @param item
     *            the item being added to the back of the list
     * @param index
     *            the index position where the new item is being added
     */
    public void add(int index, T item) {
        if (index >= 0 && index <= this.size()) {
            Node newNode = new Node(item);
            if (index == 0) {
                newNode.insertAfter(this.head);
            }
            else {
                Node previousNode = this.getNodeAtIndex(index - 1);
                newNode.insertAfter(previousNode);
            }
        }

        else {
            throw new IndexOutOfBoundsException();
        }
    }


    /**
     * adds a new item to the back of the list
     * 
     * @param item
     *            the item being added to the back of the list
     */
    public void addToBack(T item) {
        Node node = new Node(item);
        node.insertAfter(this.tail.getPrevious());
    }


    /**
     * adds a new item to the front of the list
     * 
     * @param item
     *            the item being added to the front of the list
     */
    public void addToFront(T item) {
        Node node = new Node(item);
        node.insertAfter(this.head);
    }


    /**
     * removes a certain specified item from the list
     * 
     * @param item
     *            the item being removed
     * @return true if the item is properly removed
     */
    public boolean remove(T item) {

        Node current = head.getNext();
        for (int i = 0; i < size; i++) {
            if (current.data.equals(item)) {
                current.remove();
                return true;
            }
            current = current.getNext();
        }
        return false;
    }


    /**
     * removes the item at the specified index
     * 
     * @param index
     *            the index of the item that is being removed
     * @return true if the item is properly removed
     */
    public boolean remove(int index) {
        if (index >= 0 && index < this.size()) {
            Node toRemove = this.getNodeAtIndex(index);
            toRemove.remove();
            return true;
        }
        else {
            return false;
        }
    }


    /**
     * gets and returns the item at a specified index
     * 
     * @param index
     *            the index of the wanted item
     * @return the value of the item at the specified index
     */
    public T get(int index) {
        if (index >= 0 && index < this.size()) {
            Node toGet = this.getNodeAtIndex(index);
            return toGet.data;
        }
        else {
            throw new IndexOutOfBoundsException();
        }
    }


    /**
     * clears the doublyLinkedList of all values
     */
    public void clear() {

        this.head.linkWith(this.tail);
        this.size = 0;

    }


    /**
     * returns the size (number of entries) of the doublyLinkedList
     * 
     * @return size
     */
    public int size() {
        return this.size;
    }


    /**
     * determines whether the list is empty or not empty
     * 
     * @return true if the list is empty
     */
    public boolean isEmpty() {
        return this.size() == 0;

    }


    /**
     * translates all items in the doubly linked list into an array for easier
     * manipulation and calculation
     * 
     * @return an array of the items in the list
     */
    public Object[] toArray() {
        Object[] returnArray = new Object[this.size];
        LinkedIterator<T> itr = new LinkedIterator<T>();

        int i = 0;
        while (itr.hasNext()) {
            returnArray[i] = itr.next();
            i++;
        }

        return returnArray;
    }


    /**
     * a helper method to get the node at a certain index
     * 
     * @param index
     * @return
     */
    private Node getNodeAtIndex(int index) {
/*        if (index < 0 || this.size() <= index) {
            throw new IndexOutOfBoundsException("No element exists at "
                + index);
        }
*/
        Node current = head.getNext();

        for (int i = 0; i < index; i++) {
            current = current.getNext();
        }

        return current;

    }


    /**
     * allows the user to instantiate a new linkedIterator for traversal of
     * their doubly linked list
     * 
     * @return
     */
    public Iterator<T> iterator() {
        return new LinkedIterator<T>();
    }
    
    /**
     * sorts the list in terms of the T in the list
     */
    public DoublyLinkedList<T> sortList(Comparator<? super T> comparator)
    {   
 
        if (this.size() > 1) 
        {
            T tempNode = null; 
            //starts at second node in the list and moves to end of list
            for (Node startNode = head.getNext().getNext(); startNode != tail; startNode = startNode.getNext()) {
                
                //starts at the same node as the inner loop and moves backward
                for (Node mainNode = startNode; mainNode != head.getNext(); mainNode = mainNode.getPrevious()) {
 
                    //if the data at the main compare is less than the data at the previous node
                    if (comparator.compare(mainNode.getData(), mainNode.getPrevious().getData()) < 0) {
                        
                        tempNode = mainNode.getData(); //set a temp variable with the main comparison node
                        mainNode.setData(mainNode.getPrevious().getData()); //sets the main comp as the previous
                        mainNode.getPrevious().setData(tempNode); //sets the previous as the temp of the prev. main comp
                    }
                }
            }
        }
        return this;
   
        
    }


    /**
     * This is the inner class LiinkedIterator which creates a new iterator that
     * can traverse through a doublyLinkedList
     *
     * @author Charlotte Hahn <chahn44>
     * @version 4/9/2018
     * @param <T>
     */
    private class LinkedIterator<T> implements Iterator<T> {

        private Node node;
        private boolean wasNextCalled;


        /**
         * Creates a new LinkedIterator
         */
        public LinkedIterator() {
            this.node = head;
            wasNextCalled = false;

        }


        /**
         * Checks if there are more elements in the list
         *
         * @return true if there are more elements in the list
         */
        @Override
        public boolean hasNext() {
            if (this.node.getNext() != tail) {
                return this.node != null;
            }
            return false;
        }


        /**
         * Gets the next value in the list
         *
         * @return the next value
         * @throws NoSuchElementException
         *             if there are no nodes left in the list
         */
        @SuppressWarnings("unchecked")
        @Override
        public T next() {
            if (hasNext()) {
                Node returnNode = this.node.getNext();
                this.node = this.node.getNext();
                wasNextCalled = true;
                return (T)returnNode.getData();

            }
            else {
                throw new NoSuchElementException("Illegal call to next(); "
                    + "iterator is after end of list.");
            }

        }


        /**
         * Removes the last object returned with next() from the list
         *
         * @throws IllegalStateException
         *             if next has not been called yet
         *             and if the element has already been removed
         */
        @Override
        public void remove() {
            if (wasNextCalled) {
                Node toRemove = this.node;
                toRemove.getNext().setPrevious(toRemove.getPrevious());
                toRemove.getPrevious().setNext(toRemove.getNext());
                size--;
                wasNextCalled = false;
                node = null;
            }
            else {
                throw new IllegalStateException();
            }
        }
    }


    /**
     * This is the inner class Node which creates a new node with a data field
     * for the doubly linked list to use
     *
     * @author Charlotte Hahn <chahn44>
     * @version 4/9/2018
     */
    private class Node {

        private Node next;
        private Node prev;
        private T data;


        /**
         * Node constructor no parameters
         */
        public Node() {

        }


        /**
         * Node constructor with parameters
         * 
         * @param key
         * @param value
         */
        public Node(T data) {
            this.data = data;
        }


        /**
         * returns the data of a node
         * 
         * @return data
         */
        public T getData() {
            return this.data;
        }


        /**
         * gets and returns the previous reference of a node
         * 
         * @return
         */
        public Node getPrevious() {
            return this.prev;
        }


        /**
         * sets the previous reference of a Node to another new node
         * 
         * @param newNode
         */
        public void setPrevious(Node previous) {
            this.prev = previous;
        }


        /**
         * gets and returns the next reference of a node
         * 
         * @return the next node
         */
        public Node getNext() {
            return this.next;
        }
        
        /**
         * gets the data of the node
         */
        public void setData(T data) {
            this.data = data;
        }


        /**
         * sets the next reference of a Node to another new node
         * 
         * @param newNode
         */
        public void setNext(Node next) {
            this.next = next;
        }


        /**
         * links the node calling linkWith the node in the method's parameters
         * 
         * @param nextNode
         *            the node being added
         */
        private void linkWith(Node nextNode) {
            this.setNext(nextNode);
            nextNode.setPrevious(this);
        }


        /**
         * inserts the Node calling insertAfter after the Node in the method's
         * parameters
         * 
         * @param current
         */
        private void insertAfter(Node current) {

            this.linkWith(current.getNext());
            current.linkWith(this);
            size++;
        }


        /**
         * removes the node calling remove
         */
        private void remove() {
            this.prev.linkWith(this.next);
            size--;
        }
    }

}