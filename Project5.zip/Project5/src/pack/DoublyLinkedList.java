package pack;

import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;

public class DoublyLinkedList<T> implements LinkedList<T> {

    private int size;
    private Node head;
    private Node tail;


    public DoublyLinkedList() {
        this.size = 0;
        this.head = new Node();
        this.tail = new Node();
        this.head.linkWith(this.tail);
    }


    @Override
    public void add(int index, T data) {
        if (index >= 0 && index <= this.size()) {
            Node newNode = new Node(data);
            Node previousNode = this.getNodeAtIndex(index - 1);

            newNode.insertAfter(previousNode);
        }
        else {
            throw new IndexOutOfBoundsException();
        }
    }


    public void addToBack(T item) {
        Node node = new Node(item);
        node.insertAfter(this.tail.getPrevious());
    }


    public void addToFront(T item) {
        Node node = new Node(item);
        node.insertAfter(this.head);
    }


    @Override
    public boolean remove(T data) {

        Node current = head.getNext();
        for (int i = 0; i < size; i++) {
            if (current.data.equals(data)) {
                current.remove();
                return true;
            }
            current = current.getNext();
        }
        return false;
    }

    


    public boolean remove(int index) {
        if (index >= 0 && index < this.size()) {
            Node toRemove = this.getNodeAtIndex(index);
            toRemove.remove();
            return true;
        }
        else {
            throw new IndexOutOfBoundsException();
        }
    }


    @Override
    public T get(int index) {
        if (index >= 0 && index < this.size()) {
            Node toGet = this.getNodeAtIndex(index);
            return toGet.data;
        }
        else {
            throw new IndexOutOfBoundsException();
        }
    }


    @Override
    public void clear() {

        this.head.linkWith(this.tail);
        size = 0;

    }


    @Override
    public int size() {
        return this.size;
    }


    @Override
    public boolean isEmpty() {
        return this.size() == 0;

    }


    @Override
    public Object[] toArray() {
        // TODO Auto-generated method stub
        return null;
    }


    private Node getNodeAtIndex(int index) {
        if (index < 0 || size() <= index) {
            throw new IndexOutOfBoundsException("No element exists at "
                + index);
        }
        Node current = head.getNext();
        for (int i = 0; i < index; i++) {
            current = current.getNext();
        }
        return current;
    }

// ///////////////////////////// Iterator ////////////////////
//
// private class LinkedIterator<E> implements ListIterator<T> {
//
// private Node node;
// private boolean wasNextCalled;
//
//
// /**
// * Creates the iterator
// */
// public DoublyLinkedIterator() {
// node = head.getNext();
// wasNextCalled = false;
// }
//
//
// @Override
// public void add(T arg0) {
// // TODO Auto-generated method stub
//
// }
//
//
// @Override
// public boolean hasPrevious() {
// // TODO Auto-generated method stub
// return false;
// }
//
//
// @Override
// public int nextIndex() {
// // TODO Auto-generated method stub
// return 0;
// }
//
//
// @Override
// public T previous() {
// // TODO Auto-generated method stub
// return null;
// }
//
//
// @Override
// public int previousIndex() {
// // TODO Auto-generated method stub
// return 0;
// }
//
//
// @Override
// public void remove() {
// // TODO Auto-generated method stub
//
// }
//
//
// @Override
// public void set(T arg0) {
// // TODO Auto-generated method stub
//
// }
//
//
// @Override
// public boolean hasNext() {
// // TODO Auto-generated method stub
// return false;
// }
//
//
// @Override
// public T next() {
// // TODO Auto-generated method stub
// return null;
// }
// }


    /////////////////////////// Node ////////////////////////////

    private class Node {

        private Node next;
        private Node prev;
        private T data;


        /**
         * Node constructor no parameters
         */
        public Node() {

        }


        /**
         * Node constructor with parameters
         * 
         * @param key
         * @param value
         */
        public Node(T data) {
            this.data = data;
        }


        /**
         * returns the data of a node
         * 
         * @return data
         */
        public T getData() {
            return this.data;
        }


        /**
         * sets the data of a node
         * 
         * @param newData
         */
        public void setData(T data) {
            this.data = data;
        }


        /**
         * gets and returns the previous reference of a node
         * 
         * @return
         */
        public Node getPrevious() {
            return this.prev;
        }


        /**
         * sets the previous reference of a Node to another new node
         * 
         * @param newNode
         */
        public void setPrevious(Node previous) {
            this.prev = previous;
        }


        /**
         * gets and returns the next reference of a node
         * 
         * @return the next node
         */
        public Node getNext() {
            return this.next;
        }


        /**
         * sets the next reference of a Node to another new node
         * 
         * @param newNode
         */
        public void setNext(Node next) {
            this.next = next;
        }


        /**
         * links the node calling linkWith the node in the method's parameters
         * 
         * @param nextNode
         *            the node being added
         */
        private void linkWith(Node nextNode) {
            this.setNext(nextNode);
            nextNode.setPrevious(this);
        }


        /**
         * inserts the Node calling insertAfter after the Node in the method's
         * parameters
         * 
         * @param current
         */
        private void insertAfter(Node current) {

            this.linkWith(current.getNext());
            current.linkWith(this);
            size++;
        }


        /**
         * removes the node calling remove
         */
        private void remove() {
            this.prev.linkWith(this.next);
            size--;
        }
    }


    @Override
    public void add(T object) {
        // TODO Auto-generated method stub

    }


    @Override
    public boolean remove(int index, T object) {
        // TODO Auto-generated method stub
        return false;
    }

}

