package pack;

import java.util.Comparator;

public class CompareByYear implements Comparator<Glyph> {
    
    public CompareByYear() {
        // blank
    }

    @Override
    public int compare(Glyph o1, Glyph o2) {
        // TODO Auto-generated method stub
        return 0;
    }
    
    /**
     * returns a value less than 0 if the argument is a string lexicographically
     * greater than this string
     * returns 0 if equals
     * returns a value greater than 0 if argument is lexicographically less than
     * this string
     * 
     * @param glyph1
     * @param glyph2
     * @return
     */
//    public int compare(Glyph glyph1, Glyph glyph2) {
//        return glyph1.getSong().getYear().compareTo(glyph2.getSong()
//            .getYear());
//    }
    
    

}
