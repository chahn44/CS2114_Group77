package pack;

//Virginia Tech Honor Code Pledge:
//
//As a Hokie, I will conduct myself with honor
//and integrity at all times.
//I will not lie, cheat, or steal, nor
//will I accept the actions of those who do.
//-- Adam Meyer (arm88)

/**
* Gui Window
*
* @author Adam Meyer (arm88)
* @version 2018.04.01
*/ 

public class Input {
    
    public static void main(String[] args) {
        
        GlyphListBuilder glyphlist = new GlyphListBuilder();
       glyphlist.printGlyphList("MusicSurveyData.csv", "SongList.csv");
        
    }
    
   
}
