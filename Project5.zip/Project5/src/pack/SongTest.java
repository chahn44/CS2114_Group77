/**
 * 
 */
package pack;

import java.util.Arrays;

/**
 * @author Johnny
 *
 */
public class SongTest extends student.TestCase{
    //Fields
    private SongReader songRead;
    private StudentReader studentRead;
    private Song song;
    private DoublyLinkedList<Song> songList;
    private DoublyLinkedList<Student> studentList;
    
    
    /**
     * setus up and instantiates all fields
     */
    public void setUp()
    {
         songRead = new SongReader("SongListTest1.csv");
         songRead.readSongs();
         songList = songRead.getList();
         studentRead = new StudentReader("MusicSurveyDataTest1.csv");
         studentRead.readStudents();
         studentList = studentRead.getList();
    }
    
    /**
     * test setSortInfo
     */
    public void testSetSortInfo()
    {
       // System.out.print(songList.size());
        song = songList.get(2);
        song.setSortInfo(studentList);
        int[][] hobby = new int[2][4];
        int[][] major = new int[2][4];
        int[][] region = new int[2][4];
        /**
         * top row in the 2d array is the has heard number
         * bottom is the doesLike number;
         * 
         * column 1 for the hobby array is read, col 2 = art
         * col 3 = sports, col 4 = music
         * 
         * for the major array, col 1 = CS, col 2 = other engineering
         * col 3 = Math or CMDA, col 4 = other
         * 
         * for regon array, col 1 = Northeast
         * col 2 = SouthEast, col 3 = rest of US,
         * col 4 = outside US
         */
        hobby[0][0] = 1;
        hobby[0][1] = 0;
        hobby[0][2] = 3;
        hobby[0][3] = 0;
        hobby[1][0] = 0;
        hobby[1][1] = 0;
        hobby[1][2] = 3;
        hobby[1][3] = 0;
        
        major[0][0] = 1;
        major[0][1] = 0;
        major[0][2] = 3;
        major[0][3] = 0;
        major[1][0] = 2;
        major[1][1] = 0;
        major[1][2] = 1;
        major[1][3] = 0;
        
        region[0][0] = 0;
        region[0][1] = 4;
        region[0][2] = 0;
        region[0][3] = 0;
        region[1][0] = 0;
        region[1][1] = 3;
        region[1][2] = 0;
        region[1][3] = 0;
        System.out.println(Arrays.deepToString(song.getHobbyInfo()));
        assertTrue(Arrays.equals(song.getHobbyInfo(), hobby));
        assertTrue(Arrays.equals(song.getMajorInfo(), major));
        assertTrue(Arrays.equals(song.getRegionInfo(), region));
    }

}
