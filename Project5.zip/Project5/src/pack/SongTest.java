// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept
// the actions of those who do.
// -- Your name (jjaffee)

/**
 * Tests some of the methods used in song
 * does not test the getter methods, because these methods are essentially
 * implemented in the SongReader class, and are also tested in the
 * SongReader class
 */
package pack;

import java.util.Arrays;

/**
 * @author Johnny Jaffee (jjaffee)
 * @version (2018.04.09)
 */
public class SongTest extends student.TestCase {
    // Fields
    private SongReader songRead;
    private StudentReader studentRead;
    private Song song;
    private DoublyLinkedList<Song> songList;
    private DoublyLinkedList<Student> studentList;


    /**
     * setus up and instantiates all fields
     */
    public void setUp() {
        songRead = new SongReader("SongListTest1.csv");
        songRead.readSongs();
        songList = songRead.getList();
        studentRead = new StudentReader("MusicSurveyDataTest1.csv");
        studentRead.readStudents();
        studentList = studentRead.getList();
    }


    /**
     * test setSortInfo, makes sure that all the data is
     * sorted by the given sort category correctly
     */
    public void testSetSortInfo() {
        // System.out.print(songList.size());
        song = songList.get(2);
        song.setSortInfo(studentList);
        double[][] hobby = new double[2][4];
        double[][] major = new double[2][4];
        double[][] region = new double[2][4];
        /**
         * top row in the 2d array is the has heard number
         * bottom is the doesLike number;
         * 
         * column 0 for the hobby array is read, col 1 = art
         * col 2 = sports, col 3 = music
         * 
         * for the major array, col 0 = CS, col 1 = other engineering
         * col 2 = Math or CMDA, col 3 = other
         * 
         * for regon array, col 0 = Northeast
         * col 1 = SouthEast, col 2 = rest of US,
         * col 3 = outside US
         */
        // song.printSongInfo();
        // song.printHobbyInfo();
        assertEquals(2, song.getSongNumber());
        hobby[0][0] = 100.0;
        hobby[0][1] = 0.0;
        hobby[0][2] = 75.0;
        hobby[0][3] = 0.0;
        hobby[1][0] = 0.0;
        hobby[1][1] = 0.0;
        hobby[1][2] = 75.0;
        hobby[1][3] = 0.0;

        major[0][0] = (1.0 / 3.0) * 100.0;
        major[0][1] = 0;
        major[0][2] = 100.0;
        major[0][3] = 0.0;
        major[1][0] = (2.0 / 3.0) * 100.0;
        major[1][1] = 0.0;
        major[1][2] = (1.0 / 3.0) * 100.0;

        major[1][3] = 0.0;

        region[0][0] = 0.0;
        region[0][1] = (4.0 / 6.0) * 100.0;
        region[0][2] = 0;
        region[0][3] = 0;
        region[1][0] = 0;
        region[1][1] = 50.0;
        region[1][2] = 0;
        region[1][3] = 0;
        // System.out.println(Arrays.deepToString(song.getMajorInfo()));
        // System.out.println(Arrays.deepToString(major));
        assertTrue(Arrays.deepEquals(song.getHobbyInfo(), hobby));
        assertTrue(Arrays.deepEquals(song.getMajorInfo(), major));
        assertTrue(Arrays.deepEquals(song.getRegionInfo(), region));
    }

}
