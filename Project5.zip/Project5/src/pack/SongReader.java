/**
 * 
 */
package pack;

import java.util.Scanner;

/**
 * @author Johnny
 *
 */
public class SongReader {
    //Fields
    private Scanner scanner;
    private DoublyLinkedList<Song> songList;
    private Song currentSong;
    
    /**
     * constructor, sets up scanner
     * @param id = file name to read song data from
     */
    public SongReader(String id)
    {
        scanner = new Scanner(new File(id));
        songList = new DoublyLinkedList<Song>();
    }
    
    /**
     * reads songs from text file and stores it in
     * a doubly linked list
     */
    public void readSongs()
    {
        String line;
        String title;
        String artist; 
        String genre;
        int year;
        String[] parse; 
        int number = 0;
        
        while (scanner.hasNextLine())
        {
            line = scanner.nextLine();
            parse = line.split(",");
            title = parse[0];
            artist = parse[1];
            year = Integer.parseInt(parse[2]);
            genre = parse[3];
            currentSong = new Song(title, genre, year, artist, number);
            songList.addBack(currentSong);
            number++;
        }
    }
    
    /**
     * returns song list
     * @precondition = readSongs must be called first
     * @return = song list
     */
    public DoublyLinkedList<Song> getList()
    {
        return songList;
    }

}
