// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept
// the actions of those who do.
// -- Your name (jjaffee)

/**
 * defines student object, designed to allow for storage
 * of neccesary information for a student read in from file.
 */
package pack;

import java.util.ArrayList;
import java.util.Iterator;

/**
 * @author Johnny Jaffee (jjaffee)
 * @version (2018.04.09)
 */
public class Student {
    // Fields
    private String hobby;
    private String major;
    private String region;
    private ArrayList<Integer> hasHeard;
    private ArrayList<Integer> doesLike;


    /**
     * constructor, intializes all fields
     * 
     * @param heard
     *            = boolean array if student has heard songs
     * @param likes
     *            = boolean array for is student likes song
     * @param maj
     *            = student major
     * @param reg
     *            = student region
     * @param hob
     *            = student hobby
     */
    public Student(
        ArrayList<Integer> heard,
        ArrayList<Integer> likes,
        String maj,
        String reg,
        String hob) {
        hasHeard = heard;
        doesLike = likes;
        major = maj;
        region = reg;
        hobby = hob;
    }


    /**
     * returns students hobby
     * 
     * @return = hobby
     */
    public String getHobby() {
        return hobby;
    }


    /**
     * retruns students major
     * 
     * @return = major
     */
    public String getMajor() {
        return major;
    }


    /**
     * returns student's region
     * 
     * @return = region as a String
     */
    public String getRegion() {
        return region;
    }


    /**
     * returns a integer arraylist corresponding to what
     * songs the student has heard
     * 
     * @return = hasHeard integer arraylist
     */
    public ArrayList<Integer> getHasHeard() {
        return hasHeard;
    }


    /**
     * returns boolean array corresponding to what
     * songs the student likes
     * 
     * @return = integer arraylist of what songs student likes
     */
    public ArrayList<Integer> getDoesLike() {
        return doesLike;
    }

    /**
     * Returns a string representation of all data about student,
     * in order major, region, hobby, and then hasHeard and doesLiked as pairs
     * 
     * [aero, northeast, reading, (1,1), ...(1,0)]
     * 
     * 1 = yes, -1 = no, 0 = not data, may have "" for missing data
     * 
     * An empty linked-list is simply [].
     *
     * @return a string representation of the linked-list's keys
     * 
     *         public String toString() {
     *         StringBuilder builder = new StringBuilder();
     * 
     *         builder.append("[");
     *         builder.append(major);
     *         builder.append(", ");
     *         builder.append(region);
     *         builder.append(", ");
     *         builder.append(hobby);
     *         builder.append(", ");
     *         for (int i = 0; i < doesLike.size(); i++)
     *         {
     *         builder.append("(");
     *         builder.append(Integer.toString(hasHeard.get(i)));
     *         builder.append(", ");
     *         builder.append(Integer.toString(doesLike.get(i)));
     *         builder.append(")");
     *         builder.append(", ");
     *         }
     *         builder.append("]");
     *         return builder.toString();
     *         }
     */

}
