package pack;



public class InputReader {
    
} 
