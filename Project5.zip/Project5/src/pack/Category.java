package pack;

public enum Category {
    hobby, major, region;
}
