// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept
// the actions of those who do.
// -- Your name (jjaffee)

/**
 * Defines methods available for song objects
 * includes some sorting
 * 
 */
package pack;

/**
 * @author Johnny Jaffee
 * @version (2018.04.08)
 * 
 */
public class Song {
    // Fields
    private String songTitle;
    private String songGenre;
    private int songYear;
    private String songArtist;
    private int songNumber;
    private double[][] hobbyInfo;
    private double[][] majorInfo;
    private double[][] regionInfo;
    private double[] count; // represents number of instances for sorting
                            // criteria


    /**
     * constructor, sets all fields for a given song
     * 
     * @param title
     *            = title of the song as String
     * @param genre
     *            = song genre
     * @param year
     *            = song year
     * @param artist
     *            = song artist
     */
    public Song(
        String title,
        String genre,
        int year,
        String artist,
        int songNum) {
        songTitle = title;
        songGenre = genre;
        songYear = year;
        songArtist = artist;
        songNumber = songNum;
        hobbyInfo = new double[2][4];
        majorInfo = new double[2][4];
        regionInfo = new double[2][4];
        count = new double[12];

    }


    /**
     * returns the title of a song
     * 
     * @return = song title
     */
    public String getTitle() {
        return songTitle;
    }


    /**
     * returns song genre
     * 
     * @return = song genre
     */
    public String getGenre() {
        return songGenre;
    }


    /**
     * returns song year
     * 
     * @return = song year
     */
    public int getYear() {
        return songYear;
    }


    /**
     * returns the song artist
     * 
     * @return = song artist
     */
    public String getArtist() {
        return songArtist;
    }


    /**
     * returns the song number,
     * which is the index of when the song was read in,
     * starts at 0
     * 
     * @return int = song number
     */
    public int getSongNumber() {
        return songNumber;
    }


    /**
     * prints out the song info, does not print out any student preference
     * sorting info
     */
    public void printSongInfo() {
        System.out.println("Song Title: " + this.getTitle());
        System.out.println("Song Artist: " + this.getArtist());
        System.out.println("Song Genre: " + this.getGenre());
        System.out.println("Song Year: " + this.getYear());
    }


    /**
     * sorts all the data into 2d arrays, each 2d array
     * represents a different sorting criteria
     * 
     * @param students
     *            = list of Student object
     */
    public void setSortInfo(DoublyLinkedList<Student> students) {
        /**
         * top row in the 2d array is the has heard number
         * bottom is the doesLike number;
         * col refers to index value
         * column 0 for the hobby array is read, col 1 = art
         * col 2 = sports, col 3 = music
         * 
         * for the major array, col 0 = CS, col 1 = other engineering
         * col 2 = Math or CMDA, col 3 = other
         * 
         * for regon array, col 0 = Northeast
         * col 1 = SouthEast, col 2 = rest of US,
         * col 3 = outside US
         */
        String studentHobby;
        String studentMajor;
        String studentRegion;
        int hasHeard;
        int doesLike;
        Student student;
        for (int i = 0; i < students.size(); i++) {
            student = students.get(i);
            studentHobby = student.getHobby();
            studentMajor = student.getMajor();
            studentRegion = student.getRegion();
            hasHeard = student.getHasHeard().get(songNumber);
            doesLike = student.getDoesLike().get(songNumber);
            this.hobbySort(studentHobby, hasHeard, doesLike);
            this.majorSort(studentMajor, hasHeard, doesLike);
            this.regionSort(studentRegion, hasHeard, doesLike);

        }
        for (int c = 0; c < 12; c++) {
            if (count[c] == 0) {
                count[c] = 1;
            }
        }
        hobbyInfo[0][0] = (((hobbyInfo[0][0]) / count[0]) * 100.0);

        hobbyInfo[1][0] = (((hobbyInfo[1][0]) / count[0]) * 100.0);
        hobbyInfo[0][1] = (((hobbyInfo[0][1]) / count[1]) * 100.0);
        hobbyInfo[1][1] = (((hobbyInfo[1][1]) / count[1]) * 100.0);
        hobbyInfo[0][2] = (((hobbyInfo[0][2]) / count[2]) * 100.0);
        hobbyInfo[1][2] = (((hobbyInfo[1][2]) / count[2]) * 100.0);
        hobbyInfo[0][3] = (((hobbyInfo[0][3]) / count[3]) * 100.0);
        hobbyInfo[1][3] = (((hobbyInfo[1][3]) / count[3]) * 100.0);
        majorInfo[0][0] = (((majorInfo[0][0]) / count[4]) * 100.0);
        majorInfo[1][0] = (((majorInfo[1][0]) / count[4]) * 100.0);
        majorInfo[0][1] = (((majorInfo[0][1]) / count[5]) * 100.0);
        majorInfo[1][1] = (((majorInfo[1][1]) / count[5]) * 100.0);
        majorInfo[0][2] = (((majorInfo[0][2]) / count[6]) * 100.0);
        majorInfo[1][2] = (((majorInfo[1][2]) / count[6]) * 100.0);
        majorInfo[0][3] = (((majorInfo[0][3]) / count[7]) * 100.0);
        majorInfo[1][3] = (((majorInfo[1][3]) / count[7]) * 100.0);
        regionInfo[0][0] = (((regionInfo[0][0]) / count[8]) * 100.0);
        regionInfo[1][0] = (((regionInfo[1][0]) / count[8]) * 100.0);
        regionInfo[0][1] = (((regionInfo[0][1]) / count[9]) * 100.0);
        regionInfo[1][1] = (((regionInfo[1][1]) / count[9]) * 100.0);
        regionInfo[0][2] = (((regionInfo[0][2]) / count[10]) * 100.0);
        regionInfo[1][2] = (((regionInfo[1][2]) / count[10]) * 100.0);
        regionInfo[0][3] = (((regionInfo[0][3]) / count[11]) * 100.0);
        regionInfo[1][3] = (((regionInfo[1][3]) / count[11]) * 100.0);

    }


    /**
     * sets student data for hobby sort
     * 
     * @param hobby
     *            = string for hobby
     * @param heard
     *            = int representing if student has heard song
     * @param like
     *            = int representing if student has liked the song
     */
    private void hobbySort(String hobby, int heard, int like) {
        if (hobby.equals("reading")) {
            count[0] = count[0] + 1.0;
            hobbyInfo[0][0] = (hobbyInfo[0][0] + heard);

            hobbyInfo[1][0] = hobbyInfo[1][0] + like;

        }
        else if (hobby.equals("art")) {
            count[1] = count[1] + 1.0;
            hobbyInfo[0][1] = hobbyInfo[0][1] + heard;
            hobbyInfo[1][1] = hobbyInfo[1][1] + like;
        }
        else if (hobby.equals("sports")) {
            count[2] = count[2] + 1.0;
            hobbyInfo[0][2] = hobbyInfo[0][2] + heard;
            hobbyInfo[1][2] = hobbyInfo[1][2] + like;
        }
        else if (hobby.equals("music")) {
            count[3] = count[3] + 1.0;
            hobbyInfo[0][3] = hobbyInfo[0][3] + heard;
            hobbyInfo[1][3] = hobbyInfo[1][3] + like;
        }
    }


    /**
     * sets song data for sorting by major
     * 
     * @param major
     *            = String representing student major
     * @param heard
     *            = int representing if student has heard the song
     * @param like
     *            = int representing if student likes the song
     */
    private void majorSort(String major, int heard, int like) {
        if (major.equals("Computer Science")) {
            count[4] = count[4] + 1.0;
            majorInfo[0][0] = majorInfo[0][0] + heard;
            majorInfo[1][0] = majorInfo[1][0] + like;
        }
        else if (major.equals("Other Engineering")) {
            count[5] = count[5] + 1.0;
            majorInfo[0][1] = majorInfo[0][1] + heard;
            majorInfo[1][1] = majorInfo[1][1] + like;
        }
        else if (major.equals("Math or CMDA")) {
            count[6] = count[6] + 1.0;
            majorInfo[0][2] = majorInfo[0][2] + heard;
            majorInfo[1][2] = majorInfo[1][2] + like;
        }
        else if (major.equals("Other")) {
            count[7] = count[7] + 1.0;
            majorInfo[0][3] = majorInfo[0][3] + heard;
            majorInfo[1][3] = majorInfo[1][3] + like;
        }
    }


    /**
     * sets song data based on region
     * 
     * @param region
     *            = string representing region student is from
     * @param heard
     *            = int rpresenting if student has heard the song
     * @param like
     *            = int represnting if student likes the song
     */
    private void regionSort(String region, int heard, int like) {
        if (region.equals("Northeast")) {
            count[8] = count[8] + 1.0;
            regionInfo[0][0] = regionInfo[0][0] + heard;
            regionInfo[1][0] = regionInfo[1][0] + like;
        }
        else if (region.equals("Southeast")) {
            count[9] = count[9] + 1.0;
            regionInfo[0][1] = regionInfo[0][1] + heard;
            regionInfo[1][1] = regionInfo[1][1] + like;
        }
        else if (region.equals(
            "United States (other than Southeast or Northwest)")) {
            count[10] = count[10] + 1.0;
            regionInfo[0][2] = regionInfo[0][2] + heard;
            regionInfo[1][2] = regionInfo[1][2] + like;
        }
        else if (region.equals("Outside of United States")) {
            count[11] = count[11] + 1.0;
            regionInfo[0][3] = regionInfo[0][3] + heard;
            regionInfo[1][3] = regionInfo[1][3] + like;
        }
    }


    /**
     * returns 2d array for all subsorting options for hobby sort
     * 
     * @return double[][] = 2d array for hobby sort
     */
    public double[][] getHobbyInfo() {
        return hobbyInfo;
    }


    /**
     * returns data for sorting by major for given song
     * 
     * @return int[][] = 2d array for likes and heard for all majors
     */
    public double[][] getMajorInfo() {
        return majorInfo;
    }


    /**
     * returns data for sorting by region for given song
     * 
     * @return double[][] = 2d array for percent likes and heards of a given
     *         song as sorted
     *         by region
     */
    public double[][] getRegionInfo() {
        return regionInfo;
    }


    /**
     * prints the sort data for a song based on the hobby
     * sort
     */
    public void printHobbyInfo() {
        System.out.println("Heard");
        StringBuilder builder = new StringBuilder();
        builder.append("reading:");
        builder.append((int)hobbyInfo[0][0]);
        builder.append(" art:");
        builder.append((int)hobbyInfo[0][1]);
        builder.append(" sports:");
        builder.append((int)hobbyInfo[0][2]);
        builder.append(" music:");
        builder.append((int)hobbyInfo[0][3]);
        System.out.println(builder.toString());
        builder = new StringBuilder();
        System.out.println("Likes");
        builder.append("reading:");
        builder.append((int)hobbyInfo[1][0]);
        builder.append(" art:");
        builder.append((int)hobbyInfo[1][1]);
        builder.append(" sports:");
        builder.append((int)hobbyInfo[1][2]);
        builder.append(" music:");
        builder.append((int)hobbyInfo[1][3]);
        System.out.println(builder.toString());
        System.out.println();
    }


    /**
     * prints the sort data for a song based on the major
     * sort
     */
    public void printMajorInfo() {
        System.out.println("Heard");
        StringBuilder builder = new StringBuilder();
        builder.append("Computer Science:");
        builder.append((int)majorInfo[0][0]);
        builder.append(" Other Engineering:");
        builder.append((int)majorInfo[0][1]);
        builder.append(" Math or CMDA:");
        builder.append((int)majorInfo[0][2]);
        builder.append(" Other:");
        builder.append((int)majorInfo[0][3]);
        System.out.println(builder.toString());
        builder = new StringBuilder();
        System.out.println("Likes");
        builder.append("Computer Science:");
        builder.append((int)majorInfo[1][0]);
        builder.append(" Other Engineering:");
        builder.append((int)majorInfo[1][1]);
        builder.append(" Math or CMDA:");
        builder.append((int)majorInfo[1][2]);
        builder.append(" other:");
        builder.append((int)majorInfo[1][3]);
        System.out.println(builder.toString());
        System.out.println();
    }


    /**
     * prints the sort data for a song based on the region
     * sort
     */
    public void printRegionInfo() {
        System.out.println("Heard");
        StringBuilder builder = new StringBuilder();
        builder.append("Northeast US:");
        builder.append((int)regionInfo[0][0]);
        builder.append(" Southeast US:");
        builder.append((int)regionInfo[0][1]);
        builder.append(" Rest of US:");
        builder.append((int)regionInfo[0][2]);
        builder.append(" Outside US:");
        builder.append((int)regionInfo[0][3]);
        System.out.println(builder.toString());
        builder = new StringBuilder();
        System.out.println("Likes");
        builder.append("Northeast US:");
        builder.append((int)regionInfo[1][0]);
        builder.append(" Southeast US:");
        builder.append((int)regionInfo[1][1]);
        builder.append(" Rest of US:");
        builder.append((int)regionInfo[1][2]);
        builder.append(" Outside US:");
        builder.append((int)regionInfo[1][3]);
        System.out.println(builder.toString());
        System.out.println();
    }

}
