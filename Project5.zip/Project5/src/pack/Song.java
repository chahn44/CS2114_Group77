/**
 * 
 */
package pack;

/**
 * @author Johnny
 *
 */
public class Song {
    //Fields
    private String songTitle;
    private String songGenre;
    private int songYear;
    private String songArtist;
    private int songNumber;
    
    /**
     * constructor, sets all fields for a given song
     * @param title = title of the song as String
     * @param genre = song genre
     * @param year = song year
     * @param artist = song artist
     */
    public Song(String title, String genre, int year, String artist, int songNum)
    {
        songTitle = title;
        songGenre = genre;
        songYear = year;
        songArtist = artist;
        songNumber = songNum;
    }
    
    /**
     * returns the title of a song
     * @return = song title
     */
    public String getTitle()
    {
        return songTitle;
    }
    
    /**
     * returns song genre
     * @return = song genre
     */
    public String getGenre()
    {
        return songGenre;
    }
    
    /**
     * retruns song year
     * @return = song year
     */
    public int getYear()
    {
        return songYear;
    }
    
    /**
     * returns the song artist
     * @return = song artist
     */
    public String getArtist()
    {
        return songArtist;
    }
    
    
    /**
     * Returns a string representation of all data about song
     * in order [title, artist, genre, year]
     * 
     * 
     * 
     * 
     * 
     * An empty linked-list is simply [].
     *
     * @return a string representation of the linked-list's keys
     */
    public String toString() {
        StringBuilder builder = new StringBuilder();
        
        builder.append("[");
        builder.append(songTitle);
        builder.append(", ");
        builder.append(songArtist);
        builder.append(", ");
        builder.append(songGenre);
        builder.append(", ");
        builder.append(songYear);
        builder.append("]");
        return builder.toString();
    }
    
    public void setHobbyInfo(DoublyLinkedList<Student> students)
    {
       
       
       for (int i = 0; i < students.length; i++ )
       {
           //TO DO
       }
       
    }

}
