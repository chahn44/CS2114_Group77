/**
 * 
 */
package pack;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author Johnny
 *
 */
public class StudentReader {
  //Fields
    private Scanner scanner;
    private DoublyLinkedList<Student> studentList;
    private Student currentStudent;
    
    /**
     * constructor, sets up scanner
     * @param id = file name to read song data from
     * @throws FileNotFoundException 
     */
    public StudentReader(String id) 
    {
        try {
            scanner = new Scanner(new File(id));
        }
        catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        scanner.useDelimiter(",");
        studentList = new DoublyLinkedList<Student>();
    }
    
    /**
     * reads songs from text file and stores it in
     * a doubly linked list
     */
    public void readStudents()
    {
       String hobby = null;
       String major = null;
       String region = null;
       ArrayList<Integer> hasHeard = new ArrayList<Integer>(100);
       ArrayList<Integer> doesLike = new ArrayList<Integer>(100);
       //int i = 0;
       String line;
       String[] data;
       String[] songData = {""}; 
       scanner.nextLine();
      // int songDataIndex = 0;
        while (scanner.hasNextLine())
        {
         //  if (scanner.hasNextInt())
          // {
              hasHeard = new ArrayList<Integer>(100);
             doesLike = new ArrayList<Integer>(100);
         //   System.out.println("next");
            line = scanner.nextLine();
            data = line.split(",", -1);
            major = data[2];
            region = data[3];
            hobby = data[4];
            songData = new String[data.length - 4];
            for (int c = 0; c < data.length - 5; c++)
            {
                songData[c] = data[5 + c];
              //  if (songData[songDataIndex] == null)
                //{
                  //  songData[songDataIndex] = "No Data";
                //}
                //System.out.println(songData[songDataIndex]);
                //System.out.print(songDataIndex);
            //}
              // if (songDataIndex > 0)
               //{
                //   for (int c = 0; c < songDataIndex; c++)
                  // {
                     //  System.out.println(c);
                       if (c % 2 == 0)
                       {
                           if (songData[c].equals("Yes"))
                           {
                              hasHeard.add(1); 
                           }
                           else if (songData[c].equals("No"))
                           {
                              hasHeard.add(0); 
                           }
                           else
                           {
                               hasHeard.add(0);
                           }
                       }
                       else
                       {
                           if (songData[c].equals("Yes"))
                           {
                              doesLike.add(1); 
                           }
                           else if (songData[c].equals("No"))
                           {
                              doesLike.add(0); 
                           }
                           else
                           {
                               doesLike.add(0);
                           } 
                       }
            }
                  // }
                   currentStudent = new Student(hasHeard, doesLike, major, region, hobby);
                   studentList.addToBack(currentStudent);
                   
             //  }
          // else
         //  {
           //    scanner.nextLine();
          // }
              
               /**
              line = scanner.nextLine();
              data = line.split(",", -1);
              major = data[2];
              region = data[3];
              hobby = data[4];
              songData = new String[data.length];
              for (songDataIndex = 0; songDataIndex < data.length - 5; songDataIndex++)
              {
                  songData[songDataIndex] = data[5 + songDataIndex];
              }
              */
          // }
           //else
          // {
              // line = scanner.nextLine();
              // data = line.split(",", -1);
              // for (int i = 0; i < data.length; i++)
              // {
                //   songData[songDataIndex + 1] = data[i];
              // }
          // }
              
        }
    }
    
    /**
     * returns song list
     * @precondition = readSongs must be called first
     * @return = song list
     */
    public DoublyLinkedList<Student> getList()
    {
        return studentList;
    }

}
