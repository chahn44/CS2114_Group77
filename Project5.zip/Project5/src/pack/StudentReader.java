// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept
// the actions of those who do.
// -- Your name (jjaffee)

/**
 * reads in data from file with student survey info
 * stores this info in doublylinkedlist
 */
package pack;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * @author Johnny Jaffee (jjaffee)
 * @version (2018.04.09)
 */
public class StudentReader {
    // Fields
    private Scanner scanner;
    private DoublyLinkedList<Student> studentList;
    private Student currentStudent;


    /**
     * constructor, sets up scanner
     * 
     * @param id
     *            = file name to read song data from
     * @throws FileNotFoundException
     */
    public StudentReader(String id) {
        try {
            scanner = new Scanner(new File(id));
        }
        catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            // e.printStackTrace();
            System.out.println("File not found");
            return;

        }
        scanner.useDelimiter(",");
        studentList = new DoublyLinkedList<Student>();
    }


    /**
     * reads songs from text file and stores it in
     * a doubly linked list, assumed one header line
     */
    public void readStudents() {
        String hobby = null;
        String major = null;
        String region = null;
        ArrayList<Integer> hasHeard = new ArrayList<Integer>(100);
        ArrayList<Integer> doesLike = new ArrayList<Integer>(100);
        // int i = 0;
        String line;
        String[] data;
        String[] songData = { "" };
        scanner.nextLine();

        while (scanner.hasNextLine()) {

            hasHeard = new ArrayList<Integer>(100);
            doesLike = new ArrayList<Integer>(100);

            line = scanner.nextLine();
            data = line.split(",", -1);
            major = data[2];
            region = data[3];
            hobby = data[4];
            songData = new String[data.length - 4];
            for (int c = 0; c < data.length - 5; c++) {
                songData[c] = data[5 + c];

                if (c % 2 == 0) {
                    if (songData[c].equals("Yes")) {
                        hasHeard.add(1);
                    }
                    else if (songData[c].equals("No")) {
                        hasHeard.add(0);
                    }
                    else {
                        hasHeard.add(0);
                    }
                }
                else {
                    if (songData[c].equals("Yes")) {
                        doesLike.add(1);
                    }
                    else if (songData[c].equals("No")) {
                        doesLike.add(0);
                    }
                    else {
                        doesLike.add(0);
                    }
                }
            }

            currentStudent = new Student(hasHeard, doesLike, major, region,
                hobby);
            studentList.addToBack(currentStudent);

        }
    }


    /**
     * returns song list
     * 
     * @precondition = readSongs must be called first
     * @return = song list
     */
    public DoublyLinkedList<Student> getList() {
        return studentList;
    }

}
