package pack;

public enum SongCategory {
    Artist, Year, Genre, Other;
}
