package pack;

import java.util.ArrayList;

//import org.apache.xpath.operations.String;

//Virginia Tech Honor Code Pledge:
//
//As a Hokie, I will conduct myself with honor
//and integrity at all times.
//I will not lie, cheat, or steal, nor
//will I accept the actions of those who do.
//-- Adam Meyer (arm88)

/**
* GlyphListBuilder
*
* @author Adam Meyer (arm88)
* @version 2018.04.01
*/ 

public class GlyphListBuilder {

    private DoublyLinkedList<Song> songs;
    private ArrayList<Glyph> glyphsByMajor;
    private ArrayList<Glyph> glyphsByHobby;
    private ArrayList<Glyph> glyphsByRegion;


    /**
     * Initializes the DoublyLinkedList, and 3 Array Lists
     * that will store the Glyphs generated based on Major,
     * Hobby and Region
     * 
     * @param songList
     *            the DoublyLinkedList passed in
     */
    public GlyphListBuilder(DoublyLinkedList<Song> songList) {
        songs = songList;
        glyphsByMajor = new ArrayList<Glyph>();
        glyphsByHobby = new ArrayList<Glyph>();
        glyphsByRegion = new ArrayList<Glyph>();
    }
    
    public GlyphListBuilder() {
      
    }


    /**
     * Returns the song list
     * 
     * @return songs
     *         the list of songs
     */
    public DoublyLinkedList<Song> getSongs() {
        return songs;
    }


    /**
     * Gets the List of Glyphs by major
     * 
     * @return glyphsByMajor
     *         the ArrayList storing the glyphs
     */
    public ArrayList<Glyph> getGlyphsByMajor() {
        return glyphsByMajor;
    }


    /**
     * Gets the List of Glyphs by hobby
     * 
     * @return glyphsByHobby
     *         the ArrayList storing the glyphs
     */
    public ArrayList<Glyph> getGlyphsByHobby() {
        return glyphsByHobby;
    }


    /**
     * Gets the List of Glyphs by region
     * 
     * @return glyphsByRegion
     *         the ArrayList storing the glyphs
     */
    public ArrayList<Glyph> getGlyphsByRegion() {
        return glyphsByRegion;
    }

    

    /**
     * Generates Glyphs based on the percentages 
     * calculated for the majors and stores them 
     * in an ArrayList
     * 
     * @return glyphsByMajor
     *         the ArrayList storing the glyphs
     */
    public List<Glyph> createGlyphsByMajor() {
        
        for (int i = 0; i < songs.size(); i++) {
            Song current = songs.get(i);
            double[][] majorInfo =  current.getMajorInfo();
           // double[][] hobbyInfo = current.getHobbyInfo();
           // double[][] regionInfo = current.getRegionInfo();
            int likePercent = (int) majorInfo[1][0]; 
            int heardPercent = (int) majorInfo[0][0]; 
            Glyph currentGlyph = new Glyph();
            currentGlyph.createLikeBar(1, likePercent);
            currentGlyph.createHeardBar(5, heardPercent);
            int likePercentTwo = (int) majorInfo[1][1];; 
            int heardPercentTwo = (int) majorInfo[0][1];
            currentGlyph.createLikeBar(2, likePercentTwo);
            currentGlyph.createHeardBar(6, heardPercentTwo);
            int likePercentThree = (int) majorInfo[1][2]; 
            int heardPercentThree = (int) majorInfo[0][2];
            currentGlyph.createLikeBar(3, likePercentThree);
            currentGlyph.createHeardBar(7, heardPercentThree);
            int likePercentFour = (int) majorInfo[1][3];
            int heardPercentFour = (int) majorInfo[0][3]; 
            currentGlyph.createLikeBar(4, likePercentFour);
            currentGlyph.createHeardBar(8, heardPercentFour);
            glyphsByMajor.add(currentGlyph);
        }
        return glyphsByMajor;
    }


    /**
     * Generates Glyphs based on the percentages 
     * calculated for the hobbies and stores them 
     * in an ArrayList
     * 
     * @return glyphsByHobby
     *         the ArrayList storing the glyphs
     */
    public ArrayList<Glyph> createGlyphsByHobby() {
        for (int i = 0; i < songs.size(); i++) {
           
            Song current = songs.get(i);
            double[][] hobbyInfo = current.getHobbyInfo();

            int likePercent = (int) hobbyInfo[1][0]; 
            int heardPercent = (int) hobbyInfo[0][0];

            Glyph currentGlyph = new Glyph();
            currentGlyph.createLikeBar(1, likePercent);
            currentGlyph.createHeardBar(5, heardPercent);

            int likePercent2 = (int) hobbyInfo[1][1];
            int heardPercent2 = (int) hobbyInfo[0][1];

            currentGlyph.createLikeBar(2, likePercent2);
            currentGlyph.createHeardBar(6, heardPercent2);

            int likePercent3 = (int) hobbyInfo[1][2];
            int heardPercent3 = (int) hobbyInfo[0][2];

            currentGlyph.createLikeBar(3, likePercent3);
            currentGlyph.createHeardBar(7, heardPercent3);

            int likePercent4 = (int) hobbyInfo[1][3];
            int heardPercent4 = (int) hobbyInfo[0][3];

            currentGlyph.createLikeBar(4, likePercent4);
            currentGlyph.createHeardBar(8, heardPercent4);

            glyphsByHobby.add(currentGlyph);
        }
        return glyphsByHobby;
    }


    /**
     * Generates Glyphs based on the percentages 
     * calculated for the states and stores them 
     * in an ArrayList
     * 
     * @return glyphsByREgion
     *         the ArrayList storing the glyphs
     */
    public ArrayList<Glyph> createGlyphsByRegion() {
        
        for (int i = 0; i < songs.size(); i++) {
            Song current = songs.get(i);
            double[][] regionInfo = current.getRegionInfo();

            int likePercent = (int) regionInfo[1][0]; 
            int heardPercent = (int) regionInfo[0][0]; 

            Glyph currentGlyph = new Glyph();
            currentGlyph.createLikeBar(1, likePercent);
            currentGlyph.createHeardBar(5, heardPercent);

            int likePercent2 = (int) regionInfo[1][1]; 
            int heardPercent2 = (int) regionInfo[0][1]; 

            currentGlyph.createLikeBar(2, likePercent2);
            currentGlyph.createHeardBar(6, heardPercent2);

            int likePercent3 = (int) regionInfo[1][2]; 
            int heardPercent3 = (int) regionInfo[0][2]; 

            currentGlyph.createLikeBar(3, likePercent3);
            currentGlyph.createHeardBar(7, heardPercent3);

            int likePercent4 = (int) regionInfo[1][3];  
            int heardPercent4 = (int) regionInfo[0][3]; 

            currentGlyph.createLikeBar(4, likePercent4);
            currentGlyph.createHeardBar(8, heardPercent4);

            glyphsByRegion.add(currentGlyph);
        }
        return glyphsByRegion;
    }
    
    /**
     * prints unordered glyph info to console
     * @param music
     * @param song
     */
    public  void printGlyphList(String music, String song ) {
        SongReader songRead = new SongReader(song);
        songRead.readSongs();
        DoublyLinkedList<Song> sortedList = songRead.getList();
        StudentReader studentRead = new StudentReader(music);
        studentRead.readStudents();
        DoublyLinkedList<Student> studentList = studentRead.getList();
        for (int i = 0; i < sortedList.size(); i++) {
            Song currentSong = sortedList.get(i);
            currentSong.setSortInfo(studentList);
            currentSong.printSongInfo();
            currentSong.printHobbyInfo();
        }
    }
    
}
