// Virginia Tech Honor Code Pledge:
//
// As a Hokie, I will conduct myself with honor and integrity at all times.
// I will not lie, cheat, or steal, nor will I accept
// the actions of those who do.
// -- Your name (jjaffee)

/**
 * tests methods used in student read and student class
 * combines both because the methods in Student are all getter methods, set by
 * StudentReader
 */
package pack;

import java.io.FileNotFoundException;
import java.util.ArrayList;

/**
 * @author Johnny Jaffee (jjaffee)
 * @version (2018.04.09)
 */
public class StudentReaderTest extends student.TestCase {
    // Fields
    private StudentReader studentReader;
    private String file = "MusicSurveyDataTest1.csv";


    /**
     * sets up and intializes fields
     */
    public void setUp() {
        studentReader = new StudentReader(file);
    }


    /**
     * test readStudents and Students getter methods
     */
    public void testReadStudents() {

        StudentReader noFile = new StudentReader("no file");

        String err = "File not found";
        assertFuzzyEquals(err, systemOut().getHistory());

        studentReader.readStudents();
        assertEquals(studentReader.getList().size(), 6);

        ArrayList<Integer> list = new ArrayList();
        list.add(1);
        list.add(1);
        list.add(1);
        list.add(0);
        list.add(1);

        assertEquals(studentReader.getList().get(0).getHasHeard(), list);
        list = new ArrayList();
        list.add(1);
        list.add(0);
        list.add(0);
        list.add(0);
        list.add(0);
        assertEquals(studentReader.getList().get(0).getDoesLike(), list);
        list = new ArrayList();
        list.add(0);
        list.add(1);
        list.add(1);
        list.add(0);
        list.add(1);
        assertEquals(studentReader.getList().get(1).getHasHeard(), list);
        assertEquals(studentReader.getList().get(2).getHobby(), "sports");
        assertEquals(studentReader.getList().get(2).getMajor(),
            "Computer Science");
        assertEquals(studentReader.getList().get(2).getRegion(), "Southeast");
    }

}
