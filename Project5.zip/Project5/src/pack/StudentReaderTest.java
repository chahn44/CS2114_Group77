/**
 * 
 */
package pack;

import java.util.ArrayList;

/**
 * @author Johnny
 *
 */
public class StudentReaderTest extends student.TestCase {
    //Fields
    private StudentReader studentReader;
    private String file = "MusicSurveyDataTest1.csv";
    
    
    /**
     * sets up and intializes fields
     */
    public void setUp()
    {
        studentReader = new StudentReader(file);
    }
    
    /**
     * test readStudents
     */
    public void testReadStudents() {
        studentReader.readStudents();
        assertEquals(studentReader.getList().size(), 6);
       // int[] list = {1, 1, 1, 0, 1};
        ArrayList<Integer> list = new ArrayList();
        list.add(1);
        list.add(1);
        list.add(1);
        list.add(0);
        list.add(1);
        //System.out.print(studentReader.getList().get(0).getHasHeard().toArray().toString());
        assertEquals(studentReader.getList().get(0).getHasHeard(), list);
        list = new ArrayList();
        list.add(1);
        list.add(0);
        list.add(0);
        list.add(0);
        list.add(0);
        assertEquals(studentReader.getList().get(0).getDoesLike(), list);
        list = new ArrayList();
        list.add(0);
        list.add(1);
        list.add(1);
        list.add(0);
        list.add(1);
        assertEquals(studentReader.getList().get(1).getHasHeard(), list);
        assertEquals(studentReader.getList().get(2).getHobby(), "sports");
        assertEquals(studentReader.getList().get(2).getMajor(), "Computer Science");
        assertEquals(studentReader.getList().get(2).getRegion(), "Southeast");
    }
    
    

}
