/**
 * 
 */
package pack;

/**
 * @author Johnny
 *
 */
public class StudentReaderTest extends student.TestCase {
    //Fields
    private StudentReader studentReader;
    private String file = "MusicSurveyData2018S.csv";
    
    
    /**
     * sets up and intializes fields
     */
    public void setUp()
    {
        studentReader = new StudentReader(file);
    }
    
    /**
     * test readStudents
     */
    public void testReadStudents() {
        studentReader.readStudents();
    }

}
